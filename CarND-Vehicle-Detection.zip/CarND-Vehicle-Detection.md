
# CarND-Vehicle-Detection

## Import libraries


```python
import numpy as np
import cv2
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import time
from sklearn.model_selection import train_test_split
from sklearn.svm import LinearSVC
from sklearn.preprocessing import StandardScaler
from skimage.feature import hog
import os
from fnmatch import fnmatch
```

## Load traning data 


```python
nv = '.\\data\\non-vehicles\\'
v = '.\\data\\vehicles\\'
pattern = "*.png"
car = []
nocar =[]
file_path = []
lable =[]
for path, subdirs, files in os.walk(nv):
    for name in files:
        if fnmatch(name,pattern):
            nocar.append(os.path.join(path, name))

for path, subdirs, files in os.walk(v):
    for name in files:
        if fnmatch(name,pattern):
            car.append(os.path.join(path, name))

            
            
```

## Feature extraction functions

Same as the functions provided in udacity exercise with some modifications  


```python
# Convert color spaces  
def convert_color(img, conv='RGB2YUV'):
    if conv == 'RGB2YCrCb':
        return cv2.cvtColor(img, cv2.COLOR_RGB2YCrCb)
    if conv == 'BGR2YCrCb':
        return cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
    if conv == 'RGB2LUV':
        return cv2.cvtColor(img, cv2.COLOR_RGB2LUV)
    if conv == 'RGB2HLS':
        return cv2.cvtColor(img, cv2.COLOR_RGB2HLS)
    if conv == 'RGB2YUV':
        return cv2.cvtColor(img, cv2.COLOR_RGB2YUV)
    if conv == 'RGB2HSV':
        return cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    
# Extract hog features 
def get_hog_features(img, orient, pix_per_cell, cell_per_block, 
                        vis=False, feature_vec=False):
    # Call with two outputs if vis==True
    if vis == True:
        features, hog_image = hog(img, orientations=orient, pixels_per_cell=(pix_per_cell, pix_per_cell),
                                  cells_per_block=(cell_per_block, cell_per_block), block_norm= 'L2-Hys',
                                  transform_sqrt=False, 
                                  visualise=vis, feature_vector=feature_vec)
        return features, hog_image
    # Otherwise call with one output
    else:      
        features = hog(img, orientations=orient, pixels_per_cell=(pix_per_cell, pix_per_cell),
                       cells_per_block=(cell_per_block, cell_per_block), block_norm= 'L2-Hys',
                       transform_sqrt=False, 
                       visualise=vis, feature_vector=feature_vec)
        return features
    
# Extract spatial features
def bin_spatial(img, size=(32, 32)):
    # Use cv2.resize().ravel() to create the feature vector
    features = cv2.resize(img, size).ravel() 
    # Return the feature vector
    return features

# Extract color histogram features  
def color_hist(img, nbins=32, bins_range=(0, 1)):
    # Compute the histogram of the color channels separately
    channel1_hist = np.histogram(img[:,:,0], bins=nbins, range=bins_range)
    channel2_hist = np.histogram(img[:,:,1], bins=nbins, range=bins_range)
    channel3_hist = np.histogram(img[:,:,2], bins=nbins, range=bins_range)
    # Concatenate the histograms into a single feature vector
    hist_features = np.concatenate((channel1_hist[0], channel2_hist[0], channel3_hist[0]))
    # Return the individual histograms, bin_centers and feature vector
    return hist_features    
    
# Define a function to extract features from a list of images
# Have this function call bin_spatial() and color_hist()
def extract_features(imgs, cspace='RGB2YUV', orient=9, 
                        pix_per_cell=8, cell_per_block=2, hog_channel=0,spatial_size=(32, 32),
                        hist_bins=32, hist_range=(0, 1)):
    # Create a list to append feature vectors to
    features = []
    # Iterate through the list of images
    for file in imgs:
        # Read in each one by one
        image = mpimg.imread(file)
        # apply color conversion if other than 'RGB'
        if cspace != 'RGB':
            feature_image = convert_color(image, conv= cspace ) 
        else: 
            feature_image = np.copy(image)      

        # Call get_hog_features() with vis=False, feature_vec=True
        if hog_channel == 'ALL':
            hog_features = []
            for channel in range(feature_image.shape[2]):
                hog_features.append(get_hog_features(feature_image[:,:,channel], 
                                    orient, pix_per_cell, cell_per_block, 
                                    vis=False, feature_vec=True))
            hog_features = np.ravel(hog_features)        
        else:
            hog_features = get_hog_features(feature_image[:,:,hog_channel], orient, 
                        pix_per_cell, cell_per_block, vis=False, feature_vec=True)
        # Apply bin_spatial() to get spatial color features
        spatial_features = bin_spatial(feature_image, size=spatial_size)
        # Apply color_hist() also with a color space option now
        hist_features = color_hist(feature_image, nbins=hist_bins, bins_range=hist_range)
        # Append the new feature vector to the features list
        features.append(np.concatenate((spatial_features, hist_features, hog_features)))
    # Return list of feature vectors
    return features

```

## Visualizing the data


```python
car_images =[]
non_car_images = []
colorspace = 'RGB2YUV'
orient = 9
pix_per_cell = 8
cell_per_block = 2
hog_channel = 0

for i in range(3):
    car_images.append(mpimg.imread(car[i]))
    non_car_images.append(mpimg.imread(nocar[i]))
    feature_image_no = convert_color(non_car_images[i], conv= 'RGB2YUV')
    feature_image_car = convert_color(car_images[i], conv= 'RGB2YUV')
    y_ch_car = feature_image_car[:,:,0]
    u_ch_car = feature_image_car[:,:,1]
    v_ch_car = feature_image_car[:,:,2]
    
    y_ch_no = feature_image_no[:,:,0]
    u_ch_no = feature_image_no[:,:,1]
    v_ch_no = feature_image_no[:,:,2]
    
    
    feature_vector,yhog_image_car = hog(y_ch_car, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
    feature_vector,uhog_image_car = hog(u_ch_car, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
    feature_vector,vhog_image_car = hog(v_ch_car, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
     
    feature_vector,yhog_image_no = hog(y_ch_no, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
    feature_vector,uhog_image_no = hog(u_ch_no, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
    feature_vector,vhog_image_no = hog(v_ch_no, orientations=orient,
                          pixels_per_cell=(pix_per_cell, pix_per_cell), 
                          cells_per_block=(cell_per_block, cell_per_block), 
                          visualise=True, feature_vector=False,
                          block_norm="L2-Hys")
    fig = plt.figure(figsize=(20,6))
    ax =fig.add_subplot(2, 4, 1)
    ax.set_title('Original')
    plt.imshow(car_images[i])
    ax =fig.add_subplot(2, 4, 2)
    ax.set_title('Y channel Hog')
    plt.imshow(yhog_image_car, cmap='gray')
    ax =fig.add_subplot(2, 4, 3)
    ax.set_title('U channel Hog')
    plt.imshow(uhog_image_car, cmap='gray')
    ax =fig.add_subplot(2, 4, 4)
    ax.set_title('V channel Hog')
    plt.imshow(vhog_image_car, cmap='gray')
    
    ax =fig.add_subplot(2, 4, 5)
    ax.set_title('Original')
    plt.imshow(non_car_images[i])
    ax =fig.add_subplot(2, 4, 6)
    ax.set_title('Y channel Hog')
    plt.imshow(yhog_image_no, cmap='gray')
    ax =fig.add_subplot(2, 4, 7)
    ax.set_title('U channel Hog')
    plt.imshow(uhog_image_no, cmap='gray')
    ax =fig.add_subplot(2, 4, 8)
    ax.set_title('V channel Hog')
    plt.imshow(vhog_image_no, cmap='gray')
    plt.show()
    
    
```


![png](output_8_0.png)



![png](output_8_1.png)



![png](output_8_2.png)


## Extract features for traning


```python

colorspace = 'RGB2YUV' # Can be RGB, HSV, LUV, HLS, YUV, YCrCb
orient = 9
pix_per_cell = 8
cell_per_block = 2
hog_channel = 0 # Can be 0, 1, 2, or "ALL"

t=time.time()
car_features = extract_features(car, cspace=colorspace, orient=orient, 
                        pix_per_cell=pix_per_cell, cell_per_block=cell_per_block, 
                        hog_channel=hog_channel)
notcar_features = extract_features(nocar, cspace=colorspace, orient=orient, 
                        pix_per_cell=pix_per_cell, cell_per_block=cell_per_block, 
                        hog_channel=hog_channel)
t2 = time.time()
print(round(t2-t, 2), 'Seconds to extract all 3 features...')
```

    209.04 Seconds to extract all 3 features...
    

## Split Traning and Testing Set


```python
# Create an array stack of feature vectors
X = np.vstack((car_features, notcar_features)).astype(np.float64)

# Define the labels vector
y = np.hstack((np.ones(len(car_features)), np.zeros(len(notcar_features))))

# Split up data into randomized training and test sets
rand_state = np.random.randint(0, 100)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=rand_state)
```

## Standardize features

Remove the mean (zero) and scale to unit variance


```python
# Fit a per-column scaler
X_scaler = StandardScaler().fit(X_train)
# Apply the scaler to X
X_train = X_scaler.transform(X_train)
X_test = X_scaler.transform(X_test)
```

## Train the model 


```python

clf = SVC(C=10,verbose=True)
#clf = LinearSVC(C=0.1 verbose=True,max_iter = 1000 )
#clf = CalibratedClassifierCV(svc)
# Check the training time for the SVC
t=time.time()
clf.fit(X_train, y_train)
t2 = time.time()
print(round(t2-t, 2), 'Seconds to train SVC...')
# Check the score of the SVC
print('Test Accuracy of SVC = ', round(clf.score(X_test, y_test), 4))
```

    [LibSVM]759.29 Seconds to train SVC...
    Test Accuracy of SVC =  0.9927
    

## Check the preciction 


```python
t=time.time()
n_predict = 10
print('My SVC predicts: ', clf.predict(X_test[0:n_predict]))
print('For these',n_predict, 'labels: ', y_test[0:n_predict])
t2 = time.time()
print(round(t2-t, 5), 'Seconds to predict', n_predict,'labels with SVC')
```

    My SVC predicts:  [1. 1. 0. 0. 1. 0. 1. 1. 1. 1.]
    For these 10 labels:  [1. 1. 0. 0. 1. 0. 1. 1. 1. 1.]
    0.19364 Seconds to predict 10 labels with SVC
    

## Function to Perform Hog Sub-sampling Window Search


```python

    
def find_cars(img, ystart, ystop, scale, svc, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins,allwindow):
    recs =[]
    draw_img = np.copy(img)
    img = img.astype(np.float32)/255
    
    # Searching only in the right half of the image starting from 720 px
    # Searching only area between ystart and ystop
    # Convert to YUV space
    img_tosearch = img[ystart:ystop,720:,:]
    ctrans_tosearch = convert_color(img_tosearch,conv= 'RGB2YUV')
    # Scale the search area befor extracting hog feature
    if scale != 1:
        imshape = ctrans_tosearch.shape
        ctrans_tosearch = cv2.resize(ctrans_tosearch, (np.int(imshape[1]/scale), np.int(imshape[0]/scale)))
    
    # Y channel from YUV    
    ch1 = ctrans_tosearch[:,:,0]

    # Define blocks and steps as above
    nxblocks = (ch1.shape[1] // pix_per_cell) - cell_per_block + 1
    nyblocks = (ch1.shape[0] // pix_per_cell) - cell_per_block + 1 
    nfeat_per_block = orient*cell_per_block**2
    
    # 64 was the orginal sampling rate, with 8 cells and 8 pix per cell
    window = 64
    nblocks_per_window = (window // pix_per_cell) - cell_per_block + 1
    cells_per_stepx = 2  # Instead of overlap, define how many cells to step
    cells_per_stepy = 2  # Instead of overlap, define how many cells to step
    nxsteps = (nxblocks - nblocks_per_window) // cells_per_stepx + 1
    nysteps = (nyblocks - nblocks_per_window) // cells_per_stepy + 1
    
    # Compute individual channel HOG features for the entire search space
    hog1 = get_hog_features(ch1, orient, pix_per_cell, cell_per_block, feature_vec=False)
    
    
    for xb in range(nxsteps):
        for yb in range(nysteps):
            ypos = yb*cells_per_stepx
            xpos = xb*cells_per_stepy
            # Extract HOG for this patch
            hog_feat1 = hog1[ypos:ypos+nblocks_per_window, xpos:xpos+nblocks_per_window].ravel() 
            hog_features = np.hstack((hog_feat1))

            xleft = xpos*pix_per_cell
            ytop = ypos*pix_per_cell

            # Extract the image patch
            subimg = cv2.resize(ctrans_tosearch[ytop:ytop+window, xleft:xleft+window], (64,64))
          
            # Get color features
            spatial_features = bin_spatial(subimg, size=spatial_size)
            hist_features = color_hist(subimg, nbins=hist_bins)

            # Scale features and make a prediction
            test_features = X_scaler.transform(np.hstack((spatial_features,hist_features,hog_features)).reshape(1, -1))     
            test_prediction = svc.predict(test_features)
            # If the patch is a car add the rectangel co ordinates to list
            if test_prediction == 1 or allwindow  :
                xbox_left = np.int(xleft*scale)
                ytop_draw = np.int(ytop*scale)
                win_draw = np.int(window*scale)
                recs.append([(xbox_left+720, ytop_draw+ystart),(xbox_left+win_draw+720,ytop_draw+win_draw+ystart)]) 
                
    return recs
```

## Visualize All windows Windows 


```python
draw_img = mpimg.imread('./test_images/test1.jpg')
# Search areas for various size
y_limits =[350,520,370,600,400,700]
# Scaling factor
scales = [1,2,3]
spatial_size = (32, 32)
hist_bins = 32
all_wind=[]

for i in range(len(scales)):
    all_wind+=(find_cars(draw_img , y_limits[i*2], y_limits[i*2+1], scales[i], clf, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins,True))    
# list out all the rectangles
for points in all_wind:
    cv2.rectangle(draw_img, points[0], points[1], (0,0,255), 4)
fig = plt.figure(figsize=(20,10))    
plt.imshow(draw_img)
print('Total no of windows considerd :',len(all_wind))
```

    Total no of windows considerd : 304
    


![png](output_22_1.png)


## Functions for removing False Positives

Heatmap and a Threshold are used to remove false positives


```python
from scipy.ndimage.measurements import label

def add_heat(heatmap, bbox_list):
    # Iterate through list of bboxes
    for box in bbox_list:
        # Add += 1 for all pixels inside each bbox
        # Assuming each "box" takes the form ((x1, y1), (x2, y2))
        heatmap[box[0][1]:box[1][1], box[0][0]:box[1][0]] += 1

    # Return updated heatmap
    return heatmap# Iterate through list of bboxes
    
def apply_threshold(heatmap, threshold):
    # Zero out pixels below the threshold
    heatmap[heatmap <= threshold] = 0
    # Return thresholded map
    return heatmap

def draw_labeled_bboxes(img, labels):
    # Iterate through all detected cars
    for car_number in range(1, labels[1]+1):
        # Find pixels with each car_number label value
        nonzero = (labels[0] == car_number).nonzero()
        # Identify x and y values of those pixels
        nonzeroy = np.array(nonzero[0])
        nonzerox = np.array(nonzero[1])
        # Define a bounding box based on min/max x and y
        bbox = ((np.min(nonzerox), np.min(nonzeroy)), (np.max(nonzerox), np.max(nonzeroy)))
        # Draw the box on the image
        if abs( bbox[1][0]- bbox[0][0]) > 30:
            cv2.rectangle(img, bbox[0], bbox[1], (0,0,255), 6)
    # Return the image
    return img

def heat_map(img,recmard):
    heat = np.zeros_like(img[:,:,0]).astype(np.float)

    heat = add_heat(heat,recmard)
    
    # Apply threshold to help remove false positives
    heat_thresh = apply_threshold(heat,2)

    # Visualize the heatmap when displaying    
    heatmap = np.clip(heat_thresh, 0, 255)

    # Find final boxes from heatmap using label function
    labels = label(heatmap)
    draw_img = draw_labeled_bboxes(np.copy(img), labels)
    return draw_img,heat,heat_thresh,heatmap 
```

## Pipeline 


```python
rectang1 = []
j=0

# Processing Pipeline
def pipv1(image):
    draw_img = np.copy(image)
    global rectang1,j
    # Search areas for various size
    y_limits =[350,520,370,600,400,700]
    # Scaling factor
    scales = [1,2,3]
    spatial_size = (32, 32)
    hist_bins = 32
    # Procrsss every 8th frame in the window i.e out of 24 frames 3 will be processed.
    if j % 8 == 0:
        rectang1 =[]
        for i in range(len(scales)):
            rectang1+=(find_cars(image, y_limits[i*2], y_limits[i*2+1], scales[i], clf, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins,False))    
    # use heat map to filter out false positives
    draw_img,heat,heat_thresh,heatmap  = heat_map(image,rectang1)
    
    j+=1
    
    return draw_img

# pipeline for diagnostics
def pip_diagnostics(image):
    draw_img = np.copy(image)
    # Search areas for various size
    y_limits =[350,520,370,600,400,700]
    # Scaling factor
    scales = [1,2,3]
    spatial_size = (32, 32)
    hist_bins = 32
    # Procrsss every 8th frame in the window i.e out of 24 frames 3 will be processed.
    rectang1 =[]
    for i in range(len(scales)):
        rectang1+=(find_cars(image, y_limits[i*2], y_limits[i*2+1], scales[i], clf, X_scaler, orient, pix_per_cell, cell_per_block, spatial_size, hist_bins,False))    
    # use heat map to filter out false positives
    draw_img,heat,heat_thresh,heatmap = heat_map(image,rectang1)
    
    return draw_img,heat,heat_thresh,heatmap,rectang1 
    
```

## Run the diagnostics pipeline on Test images 


```python
%matplotlib inline

for k in range(1,7):
    j=0
    img = mpimg.imread('./test_images/test'+str(k)+'.jpg')
    raw = np.copy(img)
    draw_img,heat,heat_thresh,heatmap,rec  = pip_diagnostics(img)
    mpimg.imsave('./output_images/v'+str(k)+'.jpg',draw_img)
    for points in rec:
        cv2.rectangle(raw, points[0], points[1], (0,0,255), 4)
    fig = plt.figure(figsize=(20,8))
    ax = fig.add_subplot(1, 4, 1)
    ax.set_title('Original')
    plt.imshow(img)
    ax = fig.add_subplot(1, 4, 2)
    ax.set_title('All Dectected Windows')
    plt.imshow(raw)
    ax = fig.add_subplot(1, 4, 3)
    ax.set_title('Heatmap with Threshold')
    plt.imshow(heat , cmap='hot')
    ax = fig.add_subplot(1, 4, 4)
    ax.set_title('Final Dectection')
    plt.imshow(draw_img)
    plt.show()
    
```


![png](output_28_0.png)



![png](output_28_1.png)



![png](output_28_2.png)



![png](output_28_3.png)



![png](output_28_4.png)



![png](output_28_5.png)


## Run the Pipeline for the video


```python
from moviepy.editor import VideoFileClip
from IPython.display import HTML
rectang1 = []
all_rec =[]
j=0
video_output = 'project_video_processed.mp4'
clip = VideoFileClip("project_video.mp4")
#clip = clip.subclip(33,43)
video_clip = clip.fl_image(pipv1)
%time video_clip.write_videofile(video_output, audio=False)
video_clip.reader.close()
video_clip.audio.reader.close_proc()
```

    [MoviePy] >>>> Building video project_video_processed.mp4
    [MoviePy] Writing video project_video_processed.mp4
    

    
      0%|                                                                                         | 0/1261 [00:00<?, ?it/s]
      0%|                                                                                 | 1/1261 [00:00<05:40,  3.70it/s]
      0%|▎                                                                                | 4/1261 [00:00<04:15,  4.92it/s]
      0%|▍                                                                                | 6/1261 [00:00<03:22,  6.20it/s]
      1%|▌                                                                                | 8/1261 [00:08<28:23,  1.36s/it]
      1%|▋                                                                               | 10/1261 [00:08<20:14,  1.03it/s]
      1%|▊                                                                               | 12/1261 [00:09<14:32,  1.43it/s]
      1%|▉                                                                               | 14/1261 [00:09<10:33,  1.97it/s]
      1%|█                                                                               | 16/1261 [00:17<33:12,  1.60s/it]
      1%|█▏                                                                              | 18/1261 [00:17<23:38,  1.14s/it]
      2%|█▎                                                                              | 20/1261 [00:17<16:57,  1.22it/s]
      2%|█▍                                                                              | 22/1261 [00:17<12:22,  1.67it/s]
      2%|█▌                                                                              | 24/1261 [00:29<43:39,  2.12s/it]
      2%|█▋                                                                              | 26/1261 [00:29<30:53,  1.50s/it]
      2%|█▊                                                                              | 28/1261 [00:29<21:59,  1.07s/it]
      2%|█▉                                                                              | 30/1261 [00:29<15:43,  1.30it/s]
      3%|██                                                                              | 32/1261 [00:37<36:20,  1.77s/it]
      3%|██▏                                                                             | 34/1261 [00:38<25:49,  1.26s/it]
      3%|██▎                                                                             | 36/1261 [00:38<18:30,  1.10it/s]
      3%|██▍                                                                             | 38/1261 [00:38<13:18,  1.53it/s]
      3%|██▌                                                                             | 40/1261 [00:46<34:48,  1.71s/it]
      3%|██▋                                                                             | 42/1261 [00:46<24:42,  1.22s/it]
      3%|██▊                                                                             | 44/1261 [00:47<17:55,  1.13it/s]
      4%|██▉                                                                             | 46/1261 [00:47<13:04,  1.55it/s]
      4%|███                                                                             | 48/1261 [00:55<34:53,  1.73s/it]
      4%|███▏                                                                            | 50/1261 [00:55<24:51,  1.23s/it]
      4%|███▏                                                                            | 51/1261 [00:56<18:24,  1.10it/s]
      4%|███▎                                                                            | 52/1261 [00:56<13:29,  1.49it/s]
      4%|███▍                                                                            | 54/1261 [00:56<10:17,  1.95it/s]
      4%|███▌                                                                            | 56/1261 [01:04<32:51,  1.64s/it]
      5%|███▋                                                                            | 58/1261 [01:05<23:20,  1.16s/it]
      5%|███▋                                                                            | 59/1261 [01:05<17:25,  1.15it/s]
      5%|███▊                                                                            | 61/1261 [01:05<12:36,  1.59it/s]
      5%|███▉                                                                            | 62/1261 [01:05<10:28,  1.91it/s]
      5%|████                                                                            | 64/1261 [01:14<32:30,  1.63s/it]
      5%|████▎                                                                           | 67/1261 [01:14<23:04,  1.16s/it]
      5%|████▍                                                                           | 69/1261 [01:14<16:36,  1.20it/s]
      6%|████▌                                                                           | 71/1261 [01:14<12:26,  1.59it/s]
      6%|████▍                                                                         | 72/1261 [01:25<1:13:40,  3.72s/it]
      6%|████▋                                                                           | 73/1261 [01:25<52:47,  2.67s/it]
      6%|████▋                                                                           | 74/1261 [01:26<38:15,  1.93s/it]
      6%|████▊                                                                           | 75/1261 [01:27<33:01,  1.67s/it]
      6%|████▊                                                                           | 76/1261 [01:27<27:47,  1.41s/it]
      6%|████▉                                                                           | 77/1261 [01:28<20:09,  1.02s/it]
      6%|████▉                                                                           | 78/1261 [01:28<17:56,  1.10it/s]
      6%|█████                                                                           | 79/1261 [01:29<16:37,  1.18it/s]
      6%|████▉                                                                         | 80/1261 [01:57<2:57:37,  9.02s/it]
      6%|█████                                                                         | 81/1261 [01:57<2:05:39,  6.39s/it]
      7%|█████                                                                         | 82/1261 [01:57<1:28:43,  4.52s/it]
      7%|█████▏                                                                        | 83/1261 [01:58<1:06:33,  3.39s/it]
      7%|█████▎                                                                          | 84/1261 [01:58<48:16,  2.46s/it]
      7%|█████▍                                                                          | 85/1261 [01:59<35:44,  1.82s/it]
      7%|█████▍                                                                          | 86/1261 [01:59<29:03,  1.48s/it]
      7%|█████▌                                                                          | 87/1261 [02:00<22:06,  1.13s/it]
      7%|█████▍                                                                        | 88/1261 [02:31<3:15:46, 10.01s/it]
      7%|█████▌                                                                        | 89/1261 [02:31<2:18:13,  7.08s/it]
      7%|█████▌                                                                        | 90/1261 [02:31<1:37:30,  5.00s/it]
      7%|█████▋                                                                        | 91/1261 [02:32<1:14:47,  3.84s/it]
      7%|█████▊                                                                          | 92/1261 [02:33<57:07,  2.93s/it]
      7%|█████▉                                                                          | 94/1261 [02:34<42:43,  2.20s/it]
      8%|██████                                                                          | 95/1261 [02:34<33:41,  1.73s/it]
      8%|█████▉                                                                        | 96/1261 [03:05<3:22:48, 10.45s/it]
      8%|██████                                                                        | 97/1261 [03:05<2:22:57,  7.37s/it]
      8%|██████                                                                        | 98/1261 [03:06<1:40:45,  5.20s/it]
      8%|██████                                                                        | 99/1261 [03:07<1:18:16,  4.04s/it]
      8%|██████▎                                                                        | 101/1261 [03:08<57:06,  2.95s/it]
      8%|██████▍                                                                        | 102/1261 [03:08<41:39,  2.16s/it]
      8%|██████▍                                                                        | 103/1261 [03:08<31:10,  1.62s/it]
      8%|██████▎                                                                      | 104/1261 [03:38<3:15:14, 10.13s/it]
      8%|██████▍                                                                      | 105/1261 [03:39<2:18:18,  7.18s/it]
      8%|██████▍                                                                      | 106/1261 [03:39<1:37:23,  5.06s/it]
      8%|██████▌                                                                      | 107/1261 [03:40<1:13:36,  3.83s/it]
      9%|██████▊                                                                        | 108/1261 [03:40<53:14,  2.77s/it]
      9%|██████▊                                                                        | 109/1261 [03:41<41:06,  2.14s/it]
      9%|██████▉                                                                        | 110/1261 [03:41<30:54,  1.61s/it]
      9%|██████▉                                                                        | 111/1261 [03:41<23:29,  1.23s/it]
      9%|██████▊                                                                      | 112/1261 [04:10<3:01:10,  9.46s/it]
      9%|██████▉                                                                      | 113/1261 [04:10<2:08:23,  6.71s/it]
      9%|██████▉                                                                      | 114/1261 [04:11<1:30:48,  4.75s/it]
      9%|███████                                                                      | 115/1261 [04:12<1:09:20,  3.63s/it]
      9%|███████▎                                                                       | 116/1261 [04:12<50:04,  2.62s/it]
      9%|███████▎                                                                       | 117/1261 [04:12<37:24,  1.96s/it]
      9%|███████▍                                                                       | 118/1261 [04:13<29:27,  1.55s/it]
      9%|███████▍                                                                       | 119/1261 [04:13<23:41,  1.24s/it]
     10%|███████▎                                                                     | 120/1261 [04:42<2:57:12,  9.32s/it]
     10%|███████▍                                                                     | 121/1261 [04:42<2:04:41,  6.56s/it]
     10%|███████▍                                                                     | 122/1261 [04:42<1:27:47,  4.62s/it]
     10%|███████▌                                                                     | 123/1261 [04:43<1:05:47,  3.47s/it]
     10%|███████▊                                                                       | 124/1261 [04:43<48:20,  2.55s/it]
     10%|███████▊                                                                       | 125/1261 [04:43<36:47,  1.94s/it]
     10%|███████▉                                                                       | 126/1261 [04:44<27:24,  1.45s/it]
     10%|███████▉                                                                       | 127/1261 [04:44<20:54,  1.11s/it]
     10%|███████▊                                                                     | 128/1261 [05:15<3:08:52, 10.00s/it]
     10%|███████▉                                                                     | 129/1261 [05:15<2:12:47,  7.04s/it]
     10%|███████▉                                                                     | 130/1261 [05:15<1:34:28,  5.01s/it]
     10%|███████▉                                                                     | 131/1261 [05:16<1:10:12,  3.73s/it]
     10%|████████▎                                                                      | 132/1261 [05:16<51:33,  2.74s/it]
     11%|████████▎                                                                      | 133/1261 [05:17<37:30,  2.00s/it]
     11%|████████▍                                                                      | 134/1261 [05:17<28:03,  1.49s/it]
     11%|████████▍                                                                      | 135/1261 [05:18<23:27,  1.25s/it]
     11%|████████▎                                                                    | 136/1261 [05:49<3:09:50, 10.12s/it]
     11%|████████▎                                                                    | 137/1261 [05:49<2:14:08,  7.16s/it]
     11%|████████▍                                                                    | 138/1261 [05:49<1:34:56,  5.07s/it]
     11%|████████▍                                                                    | 139/1261 [05:50<1:11:39,  3.83s/it]
     11%|████████▊                                                                      | 140/1261 [05:50<53:14,  2.85s/it]
     11%|████████▊                                                                      | 141/1261 [05:51<37:52,  2.03s/it]
     11%|████████▉                                                                      | 142/1261 [05:51<30:33,  1.64s/it]
     11%|████████▉                                                                      | 143/1261 [05:51<22:27,  1.21s/it]
     11%|████████▊                                                                    | 144/1261 [06:22<3:06:19, 10.01s/it]
     11%|████████▊                                                                    | 145/1261 [06:22<2:12:03,  7.10s/it]
     12%|████████▉                                                                    | 146/1261 [06:23<1:33:26,  5.03s/it]
     12%|████████▉                                                                    | 147/1261 [06:24<1:10:57,  3.82s/it]
     12%|█████████▎                                                                     | 148/1261 [06:24<51:22,  2.77s/it]
     12%|█████████▎                                                                     | 149/1261 [06:24<38:28,  2.08s/it]
     12%|█████████▍                                                                     | 150/1261 [06:25<30:24,  1.64s/it]
     12%|█████████▍                                                                     | 151/1261 [06:26<25:06,  1.36s/it]
     12%|█████████▎                                                                   | 152/1261 [06:55<3:00:28,  9.76s/it]
     12%|█████████▎                                                                   | 153/1261 [06:55<2:07:50,  6.92s/it]
     12%|█████████▍                                                                   | 154/1261 [06:55<1:30:11,  4.89s/it]
     12%|█████████▍                                                                   | 155/1261 [06:58<1:15:05,  4.07s/it]
     12%|█████████▊                                                                     | 156/1261 [06:58<53:17,  2.89s/it]
     12%|█████████▊                                                                     | 157/1261 [06:59<42:59,  2.34s/it]
     13%|█████████▉                                                                     | 158/1261 [07:00<38:12,  2.08s/it]
     13%|█████████▉                                                                     | 159/1261 [07:02<34:54,  1.90s/it]
     13%|█████████▊                                                                   | 160/1261 [07:32<3:10:39, 10.39s/it]
     13%|█████████▊                                                                   | 161/1261 [07:32<2:14:57,  7.36s/it]
     13%|█████████▉                                                                   | 162/1261 [07:33<1:35:56,  5.24s/it]
     13%|█████████▉                                                                   | 163/1261 [07:33<1:11:24,  3.90s/it]
     13%|██████████▎                                                                    | 164/1261 [07:34<51:50,  2.84s/it]
     13%|██████████▎                                                                    | 165/1261 [07:34<37:48,  2.07s/it]
     13%|██████████▍                                                                    | 166/1261 [07:35<30:46,  1.69s/it]
     13%|██████████▍                                                                    | 167/1261 [07:35<24:42,  1.35s/it]
     13%|██████████▎                                                                  | 168/1261 [08:05<2:59:56,  9.88s/it]
     13%|██████████▎                                                                  | 169/1261 [08:05<2:06:40,  6.96s/it]
     13%|██████████▍                                                                  | 170/1261 [08:05<1:29:51,  4.94s/it]
     14%|██████████▍                                                                  | 171/1261 [08:06<1:08:11,  3.75s/it]
     14%|██████████▊                                                                    | 172/1261 [08:07<49:30,  2.73s/it]
     14%|██████████▊                                                                    | 173/1261 [08:07<37:26,  2.06s/it]
     14%|██████████▉                                                                    | 174/1261 [08:08<29:33,  1.63s/it]
     14%|██████████▉                                                                    | 175/1261 [08:08<21:39,  1.20s/it]
     14%|██████████▋                                                                  | 176/1261 [08:38<2:59:32,  9.93s/it]
     14%|██████████▊                                                                  | 177/1261 [08:39<2:06:56,  7.03s/it]
     14%|██████████▊                                                                  | 178/1261 [08:39<1:29:33,  4.96s/it]
     14%|██████████▉                                                                  | 179/1261 [08:42<1:21:35,  4.52s/it]
     14%|███████████▎                                                                   | 180/1261 [08:42<57:49,  3.21s/it]
     14%|███████████▎                                                                   | 181/1261 [08:43<41:26,  2.30s/it]
     14%|███████████▍                                                                   | 182/1261 [08:44<34:43,  1.93s/it]
     15%|███████████▍                                                                   | 183/1261 [08:45<30:21,  1.69s/it]
     15%|███████████▏                                                                 | 184/1261 [09:14<2:59:00,  9.97s/it]
     15%|███████████▎                                                                 | 185/1261 [09:14<2:06:40,  7.06s/it]
     15%|███████████▎                                                                 | 186/1261 [09:15<1:30:25,  5.05s/it]
     15%|███████████▍                                                                 | 187/1261 [09:15<1:07:06,  3.75s/it]
     15%|███████████▊                                                                   | 188/1261 [09:16<48:20,  2.70s/it]
     15%|███████████▊                                                                   | 189/1261 [09:16<35:20,  1.98s/it]
     15%|███████████▉                                                                   | 190/1261 [09:16<25:49,  1.45s/it]
     15%|███████████▉                                                                   | 191/1261 [09:17<21:08,  1.19s/it]
     15%|███████████▋                                                                 | 192/1261 [09:46<2:51:16,  9.61s/it]
     15%|███████████▊                                                                 | 193/1261 [09:46<2:00:35,  6.78s/it]
     15%|███████████▊                                                                 | 194/1261 [09:46<1:25:06,  4.79s/it]
     15%|███████████▉                                                                 | 195/1261 [09:47<1:03:50,  3.59s/it]
     16%|████████████▎                                                                  | 196/1261 [09:47<45:50,  2.58s/it]
     16%|████████████▎                                                                  | 197/1261 [09:48<33:50,  1.91s/it]
     16%|████████████▍                                                                  | 198/1261 [09:49<28:08,  1.59s/it]
     16%|████████████▍                                                                  | 199/1261 [09:49<21:34,  1.22s/it]
     16%|████████████▏                                                                | 200/1261 [10:20<2:57:24, 10.03s/it]
     16%|████████████▎                                                                | 201/1261 [10:20<2:05:21,  7.10s/it]
     16%|████████████▎                                                                | 202/1261 [10:20<1:28:53,  5.04s/it]
     16%|████████████▍                                                                | 203/1261 [10:21<1:07:07,  3.81s/it]
     16%|████████████▊                                                                  | 204/1261 [10:21<49:12,  2.79s/it]
     16%|████████████▊                                                                  | 205/1261 [10:22<36:55,  2.10s/it]
     16%|████████████▉                                                                  | 206/1261 [10:22<28:20,  1.61s/it]
     16%|████████████▉                                                                  | 207/1261 [10:23<21:35,  1.23s/it]
     16%|████████████▋                                                                | 208/1261 [10:53<2:56:37, 10.06s/it]
     17%|████████████▊                                                                | 209/1261 [10:54<2:05:17,  7.15s/it]
     17%|████████████▊                                                                | 210/1261 [10:54<1:28:24,  5.05s/it]
     17%|████████████▉                                                                | 211/1261 [10:55<1:05:55,  3.77s/it]
     17%|█████████████▎                                                                 | 212/1261 [10:55<47:43,  2.73s/it]
     17%|█████████████▎                                                                 | 213/1261 [10:55<34:02,  1.95s/it]
     17%|█████████████▍                                                                 | 214/1261 [10:56<28:20,  1.62s/it]
     17%|█████████████▍                                                                 | 215/1261 [10:56<21:05,  1.21s/it]
     17%|█████████████▏                                                               | 216/1261 [11:26<2:48:12,  9.66s/it]
     17%|█████████████▎                                                               | 217/1261 [11:26<1:59:22,  6.86s/it]
     17%|█████████████▎                                                               | 218/1261 [11:26<1:25:04,  4.89s/it]
     17%|█████████████▎                                                               | 219/1261 [11:27<1:02:42,  3.61s/it]
     17%|█████████████▊                                                                 | 220/1261 [11:27<46:20,  2.67s/it]
     18%|█████████████▊                                                                 | 221/1261 [11:28<36:13,  2.09s/it]
     18%|█████████████▉                                                                 | 222/1261 [11:28<27:16,  1.58s/it]
     18%|█████████████▉                                                                 | 223/1261 [11:29<21:51,  1.26s/it]
     18%|█████████████▋                                                               | 224/1261 [12:00<2:54:03, 10.07s/it]
     18%|█████████████▋                                                               | 225/1261 [12:00<2:02:31,  7.10s/it]
     18%|█████████████▊                                                               | 226/1261 [12:00<1:27:12,  5.06s/it]
     18%|█████████████▊                                                               | 227/1261 [12:01<1:05:49,  3.82s/it]
     18%|██████████████▎                                                                | 228/1261 [12:01<47:14,  2.74s/it]
     18%|██████████████▎                                                                | 229/1261 [12:01<33:45,  1.96s/it]
     18%|██████████████▍                                                                | 230/1261 [12:02<27:34,  1.61s/it]
     18%|██████████████▍                                                                | 231/1261 [12:02<20:16,  1.18s/it]
     18%|██████████████▏                                                              | 232/1261 [12:34<2:58:46, 10.42s/it]
     18%|██████████████▏                                                              | 233/1261 [12:35<2:06:56,  7.41s/it]
     19%|██████████████▎                                                              | 234/1261 [12:35<1:30:27,  5.28s/it]
     19%|██████████████▎                                                              | 235/1261 [12:37<1:12:34,  4.24s/it]
     19%|██████████████▊                                                                | 237/1261 [12:37<51:21,  3.01s/it]
     19%|██████████████▉                                                                | 238/1261 [12:37<38:00,  2.23s/it]
     19%|██████████████▉                                                                | 239/1261 [12:38<30:46,  1.81s/it]
     19%|██████████████▋                                                              | 240/1261 [13:10<3:01:20, 10.66s/it]
     19%|██████████████▋                                                              | 241/1261 [13:10<2:07:54,  7.52s/it]
     19%|██████████████▊                                                              | 242/1261 [13:10<1:30:50,  5.35s/it]
     19%|██████████████▊                                                              | 243/1261 [13:11<1:06:57,  3.95s/it]
     19%|███████████████▎                                                               | 244/1261 [13:11<50:38,  2.99s/it]
     19%|███████████████▎                                                               | 245/1261 [13:12<37:10,  2.19s/it]
     20%|███████████████▍                                                               | 246/1261 [13:12<26:30,  1.57s/it]
     20%|███████████████▍                                                               | 247/1261 [13:13<22:42,  1.34s/it]
     20%|███████████████▏                                                             | 248/1261 [13:44<2:54:37, 10.34s/it]
     20%|███████████████▏                                                             | 249/1261 [13:44<2:03:48,  7.34s/it]
     20%|███████████████▎                                                             | 250/1261 [13:45<1:27:21,  5.18s/it]
     20%|███████████████▎                                                             | 251/1261 [13:46<1:07:40,  4.02s/it]
     20%|███████████████▊                                                               | 252/1261 [13:46<50:19,  2.99s/it]
     20%|███████████████▊                                                               | 253/1261 [13:47<35:53,  2.14s/it]
     20%|███████████████▉                                                               | 254/1261 [13:47<28:42,  1.71s/it]
     20%|███████████████▉                                                               | 255/1261 [13:48<22:12,  1.32s/it]
     20%|███████████████▋                                                             | 256/1261 [14:20<2:55:40, 10.49s/it]
     20%|███████████████▋                                                             | 257/1261 [14:20<2:04:28,  7.44s/it]
     20%|███████████████▊                                                             | 258/1261 [14:20<1:28:16,  5.28s/it]
     21%|███████████████▊                                                             | 259/1261 [14:21<1:06:30,  3.98s/it]
     21%|████████████████▎                                                              | 260/1261 [14:21<47:50,  2.87s/it]
     21%|████████████████▎                                                              | 261/1261 [14:22<37:43,  2.26s/it]
     21%|████████████████▍                                                              | 262/1261 [14:23<29:22,  1.76s/it]
     21%|████████████████▍                                                              | 263/1261 [14:23<22:43,  1.37s/it]
     21%|████████████████                                                             | 264/1261 [14:55<2:52:09, 10.36s/it]
     21%|████████████████▏                                                            | 265/1261 [14:55<2:01:20,  7.31s/it]
     21%|████████████████▏                                                            | 266/1261 [14:55<1:25:40,  5.17s/it]
     21%|████████████████▎                                                            | 267/1261 [14:56<1:03:08,  3.81s/it]
     21%|████████████████▊                                                              | 268/1261 [14:57<48:33,  2.93s/it]
     21%|████████████████▊                                                              | 269/1261 [14:57<34:35,  2.09s/it]
     21%|████████████████▉                                                              | 270/1261 [14:58<28:41,  1.74s/it]
     21%|████████████████▉                                                              | 271/1261 [14:58<21:33,  1.31s/it]
     22%|████████████████▌                                                            | 272/1261 [15:30<2:52:52, 10.49s/it]
     22%|████████████████▋                                                            | 273/1261 [15:30<2:01:56,  7.41s/it]
     22%|████████████████▋                                                            | 274/1261 [15:30<1:27:04,  5.29s/it]
     22%|████████████████▊                                                            | 275/1261 [15:31<1:06:15,  4.03s/it]
     22%|█████████████████▎                                                             | 276/1261 [15:32<47:58,  2.92s/it]
     22%|█████████████████▎                                                             | 277/1261 [15:32<35:05,  2.14s/it]
     22%|█████████████████▍                                                             | 278/1261 [15:33<28:26,  1.74s/it]
     22%|█████████████████▍                                                             | 279/1261 [15:33<20:44,  1.27s/it]
     22%|█████████████████                                                            | 280/1261 [16:04<2:45:44, 10.14s/it]
     22%|█████████████████▏                                                           | 281/1261 [16:04<1:57:14,  7.18s/it]
     22%|█████████████████▏                                                           | 282/1261 [16:04<1:23:31,  5.12s/it]
     22%|█████████████████▎                                                           | 283/1261 [16:05<1:01:47,  3.79s/it]
     23%|█████████████████▊                                                             | 284/1261 [16:05<44:41,  2.74s/it]
     23%|█████████████████▊                                                             | 285/1261 [16:06<32:47,  2.02s/it]
     23%|█████████████████▉                                                             | 286/1261 [16:07<26:23,  1.62s/it]
     23%|█████████████████▉                                                             | 287/1261 [16:07<20:08,  1.24s/it]
     23%|█████████████████▌                                                           | 288/1261 [16:39<2:50:37, 10.52s/it]
     23%|█████████████████▋                                                           | 289/1261 [16:39<2:00:17,  7.43s/it]
     23%|█████████████████▋                                                           | 290/1261 [16:40<1:25:30,  5.28s/it]
     23%|█████████████████▊                                                           | 291/1261 [16:40<1:03:43,  3.94s/it]
     23%|██████████████████▎                                                            | 292/1261 [16:41<46:58,  2.91s/it]
     23%|██████████████████▎                                                            | 293/1261 [16:41<33:59,  2.11s/it]
     23%|██████████████████▍                                                            | 294/1261 [16:42<26:10,  1.62s/it]
     23%|██████████████████▍                                                            | 295/1261 [16:43<23:12,  1.44s/it]
     23%|██████████████████                                                           | 296/1261 [17:15<2:53:06, 10.76s/it]
     24%|██████████████████▏                                                          | 297/1261 [17:15<2:02:10,  7.60s/it]
     24%|██████████████████▏                                                          | 298/1261 [17:16<1:27:14,  5.44s/it]
     24%|██████████████████▎                                                          | 299/1261 [17:17<1:05:18,  4.07s/it]
     24%|██████████████████▊                                                            | 300/1261 [17:18<51:40,  3.23s/it]
     24%|██████████████████▊                                                            | 301/1261 [17:18<37:03,  2.32s/it]
     24%|██████████████████▉                                                            | 302/1261 [17:19<29:25,  1.84s/it]
     24%|██████████████████▉                                                            | 303/1261 [17:19<23:03,  1.44s/it]
     24%|██████████████████▌                                                          | 304/1261 [17:51<2:48:38, 10.57s/it]
     24%|██████████████████▌                                                          | 305/1261 [17:51<1:59:17,  7.49s/it]
     24%|██████████████████▋                                                          | 306/1261 [17:52<1:24:57,  5.34s/it]
     24%|██████████████████▋                                                          | 307/1261 [17:53<1:05:28,  4.12s/it]
     24%|███████████████████▎                                                           | 308/1261 [17:53<47:16,  2.98s/it]
     25%|███████████████████▎                                                           | 309/1261 [17:54<33:52,  2.14s/it]
     25%|███████████████████▍                                                           | 310/1261 [17:54<27:12,  1.72s/it]
     25%|███████████████████▍                                                           | 311/1261 [17:55<22:41,  1.43s/it]
     25%|███████████████████                                                          | 312/1261 [18:25<2:39:44, 10.10s/it]
     25%|███████████████████                                                          | 313/1261 [18:26<1:53:05,  7.16s/it]
     25%|███████████████████▏                                                         | 314/1261 [18:26<1:20:25,  5.10s/it]
     25%|███████████████████▋                                                           | 315/1261 [18:27<59:19,  3.76s/it]
     25%|███████████████████▊                                                           | 316/1261 [18:28<45:55,  2.92s/it]
     25%|███████████████████▊                                                           | 317/1261 [18:28<33:47,  2.15s/it]
     25%|███████████████████▉                                                           | 318/1261 [18:28<24:09,  1.54s/it]
     25%|███████████████████▉                                                           | 319/1261 [18:29<21:06,  1.34s/it]
     25%|███████████████████▌                                                         | 320/1261 [18:59<2:36:27,  9.98s/it]
     25%|███████████████████▌                                                         | 321/1261 [18:59<1:50:27,  7.05s/it]
     26%|███████████████████▋                                                         | 322/1261 [19:00<1:18:29,  5.01s/it]
     26%|████████████████████▏                                                          | 323/1261 [19:01<59:47,  3.82s/it]
     26%|████████████████████▎                                                          | 324/1261 [19:01<44:24,  2.84s/it]
     26%|████████████████████▎                                                          | 325/1261 [19:01<31:36,  2.03s/it]
     26%|████████████████████▍                                                          | 326/1261 [19:02<27:06,  1.74s/it]
     26%|████████████████████▍                                                          | 327/1261 [19:02<19:30,  1.25s/it]
     26%|████████████████████                                                         | 328/1261 [19:32<2:32:40,  9.82s/it]
     26%|████████████████████                                                         | 329/1261 [19:32<1:47:47,  6.94s/it]
     26%|████████████████████▏                                                        | 330/1261 [19:33<1:17:03,  4.97s/it]
     26%|████████████████████▋                                                          | 331/1261 [19:34<58:15,  3.76s/it]
     26%|████████████████████▊                                                          | 332/1261 [19:34<43:31,  2.81s/it]
     26%|████████████████████▊                                                          | 333/1261 [19:34<31:00,  2.00s/it]
     26%|████████████████████▉                                                          | 334/1261 [19:35<25:00,  1.62s/it]
     27%|████████████████████▉                                                          | 335/1261 [19:36<21:26,  1.39s/it]
     27%|████████████████████▌                                                        | 336/1261 [20:06<2:34:36, 10.03s/it]
     27%|████████████████████▌                                                        | 337/1261 [20:07<1:49:31,  7.11s/it]
     27%|████████████████████▋                                                        | 338/1261 [20:07<1:17:16,  5.02s/it]
     27%|████████████████████▋                                                        | 339/1261 [20:09<1:02:45,  4.08s/it]
     27%|█████████████████████▎                                                         | 340/1261 [20:09<45:34,  2.97s/it]
     27%|█████████████████████▎                                                         | 341/1261 [20:09<32:30,  2.12s/it]
     27%|█████████████████████▍                                                         | 342/1261 [20:10<25:56,  1.69s/it]
     27%|█████████████████████▍                                                         | 343/1261 [20:10<21:22,  1.40s/it]
     27%|█████████████████████                                                        | 344/1261 [20:39<2:26:38,  9.59s/it]
     27%|█████████████████████                                                        | 345/1261 [20:39<1:43:38,  6.79s/it]
     27%|█████████████████████▏                                                       | 346/1261 [20:40<1:13:26,  4.82s/it]
     28%|█████████████████████▋                                                         | 347/1261 [20:41<56:54,  3.74s/it]
     28%|█████████████████████▊                                                         | 348/1261 [20:42<45:08,  2.97s/it]
     28%|█████████████████████▊                                                         | 349/1261 [20:42<32:13,  2.12s/it]
     28%|█████████████████████▉                                                         | 350/1261 [20:43<26:19,  1.73s/it]
     28%|█████████████████████▉                                                         | 351/1261 [20:43<20:26,  1.35s/it]
     28%|█████████████████████▍                                                       | 352/1261 [21:13<2:29:30,  9.87s/it]
     28%|█████████████████████▌                                                       | 353/1261 [21:14<1:45:52,  7.00s/it]
     28%|█████████████████████▌                                                       | 354/1261 [21:14<1:14:56,  4.96s/it]
     28%|██████████████████████▏                                                        | 355/1261 [21:14<55:41,  3.69s/it]
     28%|██████████████████████▎                                                        | 356/1261 [21:15<40:51,  2.71s/it]
     28%|██████████████████████▎                                                        | 357/1261 [21:15<29:10,  1.94s/it]
     28%|██████████████████████▍                                                        | 358/1261 [21:15<22:04,  1.47s/it]
     28%|██████████████████████▍                                                        | 359/1261 [21:16<17:39,  1.17s/it]
     29%|█████████████████████▉                                                       | 360/1261 [21:47<2:31:23, 10.08s/it]
     29%|██████████████████████                                                       | 361/1261 [21:47<1:47:07,  7.14s/it]
     29%|██████████████████████                                                       | 362/1261 [21:47<1:16:05,  5.08s/it]
     29%|██████████████████████▋                                                        | 363/1261 [21:48<57:21,  3.83s/it]
     29%|██████████████████████▊                                                        | 364/1261 [21:49<41:39,  2.79s/it]
     29%|██████████████████████▉                                                        | 366/1261 [21:49<30:05,  2.02s/it]
     29%|██████████████████████▉                                                        | 367/1261 [21:49<21:40,  1.45s/it]
     29%|██████████████████████▍                                                      | 368/1261 [22:21<2:35:11, 10.43s/it]
     29%|██████████████████████▌                                                      | 369/1261 [22:21<1:49:21,  7.36s/it]
     29%|██████████████████████▌                                                      | 370/1261 [22:21<1:17:47,  5.24s/it]
     29%|███████████████████████▏                                                       | 371/1261 [22:22<58:49,  3.97s/it]
     30%|███████████████████████▎                                                       | 372/1261 [22:22<43:23,  2.93s/it]
     30%|███████████████████████▎                                                       | 373/1261 [22:23<30:49,  2.08s/it]
     30%|███████████████████████▍                                                       | 374/1261 [22:23<22:08,  1.50s/it]
     30%|███████████████████████▍                                                       | 375/1261 [22:24<19:29,  1.32s/it]
     30%|██████████████████████▉                                                      | 376/1261 [22:56<2:38:49, 10.77s/it]
     30%|███████████████████████                                                      | 377/1261 [22:57<1:52:05,  7.61s/it]
     30%|███████████████████████                                                      | 378/1261 [22:57<1:19:19,  5.39s/it]
     30%|███████████████████████▏                                                     | 379/1261 [22:58<1:01:07,  4.16s/it]
     30%|███████████████████████▊                                                       | 380/1261 [22:59<44:49,  3.05s/it]
     30%|███████████████████████▊                                                       | 381/1261 [22:59<31:58,  2.18s/it]
     30%|███████████████████████▉                                                       | 382/1261 [22:59<25:20,  1.73s/it]
     30%|███████████████████████▉                                                       | 383/1261 [23:00<19:54,  1.36s/it]
     30%|███████████████████████▍                                                     | 384/1261 [23:31<2:29:34, 10.23s/it]
     31%|███████████████████████▌                                                     | 385/1261 [23:31<1:45:51,  7.25s/it]
     31%|███████████████████████▌                                                     | 386/1261 [23:32<1:15:32,  5.18s/it]
     31%|████████████████████████▏                                                      | 387/1261 [23:33<57:35,  3.95s/it]
     31%|████████████████████████▎                                                      | 388/1261 [23:33<41:30,  2.85s/it]
     31%|████████████████████████▎                                                      | 389/1261 [23:34<31:31,  2.17s/it]
     31%|████████████████████████▍                                                      | 390/1261 [23:34<24:23,  1.68s/it]
     31%|████████████████████████▍                                                      | 391/1261 [23:35<20:21,  1.40s/it]
     31%|███████████████████████▉                                                     | 392/1261 [24:07<2:33:14, 10.58s/it]
     31%|███████████████████████▉                                                     | 393/1261 [24:07<1:48:03,  7.47s/it]
     31%|████████████████████████                                                     | 394/1261 [24:07<1:16:34,  5.30s/it]
     31%|████████████████████████▋                                                      | 395/1261 [24:09<59:42,  4.14s/it]
     31%|████████████████████████▊                                                      | 396/1261 [24:09<42:16,  2.93s/it]
     31%|████████████████████████▊                                                      | 397/1261 [24:09<30:26,  2.11s/it]
     32%|████████████████████████▉                                                      | 398/1261 [24:10<24:10,  1.68s/it]
     32%|████████████████████████▉                                                      | 399/1261 [24:10<20:26,  1.42s/it]
     32%|████████████████████████▍                                                    | 400/1261 [24:43<2:34:07, 10.74s/it]
     32%|████████████████████████▍                                                    | 401/1261 [24:43<1:48:35,  7.58s/it]
     32%|████████████████████████▌                                                    | 402/1261 [24:43<1:16:53,  5.37s/it]
     32%|█████████████████████████▏                                                     | 403/1261 [24:44<57:05,  3.99s/it]
     32%|█████████████████████████▎                                                     | 404/1261 [24:45<41:29,  2.91s/it]
     32%|█████████████████████████▎                                                     | 405/1261 [24:45<30:21,  2.13s/it]
     32%|█████████████████████████▍                                                     | 406/1261 [24:46<24:15,  1.70s/it]
     32%|█████████████████████████▍                                                     | 407/1261 [24:46<18:18,  1.29s/it]
     32%|████████████████████████▉                                                    | 408/1261 [25:16<2:23:06, 10.07s/it]
     32%|████████████████████████▉                                                    | 409/1261 [25:17<1:41:13,  7.13s/it]
     33%|█████████████████████████                                                    | 410/1261 [25:17<1:11:48,  5.06s/it]
     33%|█████████████████████████▋                                                     | 411/1261 [25:19<58:51,  4.15s/it]
     33%|█████████████████████████▊                                                     | 413/1261 [25:19<41:48,  2.96s/it]
     33%|█████████████████████████▉                                                     | 414/1261 [25:20<32:10,  2.28s/it]
     33%|█████████████████████████▉                                                     | 415/1261 [25:20<22:55,  1.63s/it]
     33%|█████████████████████████▍                                                   | 416/1261 [25:49<2:18:52,  9.86s/it]
     33%|█████████████████████████▍                                                   | 417/1261 [25:49<1:38:07,  6.98s/it]
     33%|█████████████████████████▌                                                   | 419/1261 [25:50<1:09:49,  4.98s/it]
     33%|██████████████████████████▎                                                    | 420/1261 [25:51<50:57,  3.64s/it]
     33%|██████████████████████████▍                                                    | 421/1261 [25:51<37:04,  2.65s/it]
     33%|██████████████████████████▍                                                    | 422/1261 [25:52<29:21,  2.10s/it]
     34%|██████████████████████████▌                                                    | 423/1261 [25:52<21:27,  1.54s/it]
     34%|█████████████████████████▉                                                   | 424/1261 [26:21<2:14:42,  9.66s/it]
     34%|█████████████████████████▉                                                   | 425/1261 [26:21<1:35:24,  6.85s/it]
     34%|██████████████████████████                                                   | 426/1261 [26:21<1:07:53,  4.88s/it]
     34%|██████████████████████████▊                                                    | 427/1261 [26:22<51:29,  3.70s/it]
     34%|██████████████████████████▊                                                    | 428/1261 [26:23<38:30,  2.77s/it]
     34%|██████████████████████████▉                                                    | 429/1261 [26:23<28:46,  2.08s/it]
     34%|██████████████████████████▉                                                    | 430/1261 [26:24<23:45,  1.71s/it]
     34%|███████████████████████████                                                    | 431/1261 [26:25<18:55,  1.37s/it]
     34%|██████████████████████████▍                                                  | 432/1261 [26:55<2:17:52,  9.98s/it]
     34%|██████████████████████████▍                                                  | 433/1261 [26:55<1:37:31,  7.07s/it]
     34%|██████████████████████████▌                                                  | 434/1261 [26:55<1:08:49,  4.99s/it]
     34%|███████████████████████████▎                                                   | 435/1261 [26:56<52:48,  3.84s/it]
     35%|███████████████████████████▎                                                   | 436/1261 [26:57<38:21,  2.79s/it]
     35%|███████████████████████████▍                                                   | 437/1261 [26:57<29:45,  2.17s/it]
     35%|███████████████████████████▍                                                   | 438/1261 [26:58<23:13,  1.69s/it]
     35%|███████████████████████████▌                                                   | 439/1261 [26:59<19:43,  1.44s/it]
     35%|██████████████████████████▊                                                  | 440/1261 [27:28<2:15:29,  9.90s/it]
     35%|██████████████████████████▉                                                  | 441/1261 [27:28<1:35:08,  6.96s/it]
     35%|███████████████████████████                                                  | 443/1261 [27:29<1:08:17,  5.01s/it]
     35%|███████████████████████████▊                                                   | 444/1261 [27:30<49:26,  3.63s/it]
     35%|███████████████████████████▉                                                   | 445/1261 [27:31<37:48,  2.78s/it]
     35%|███████████████████████████▉                                                   | 446/1261 [27:31<27:45,  2.04s/it]
     35%|████████████████████████████                                                   | 447/1261 [27:32<23:07,  1.70s/it]
     36%|███████████████████████████▎                                                 | 448/1261 [28:03<2:23:19, 10.58s/it]
     36%|███████████████████████████▍                                                 | 449/1261 [28:03<1:41:03,  7.47s/it]
     36%|███████████████████████████▍                                                 | 450/1261 [28:03<1:11:11,  5.27s/it]
     36%|████████████████████████████▎                                                  | 451/1261 [28:04<53:28,  3.96s/it]
     36%|████████████████████████████▎                                                  | 452/1261 [28:05<39:27,  2.93s/it]
     36%|████████████████████████████▍                                                  | 454/1261 [28:06<29:39,  2.20s/it]
     36%|████████████████████████████▌                                                  | 455/1261 [28:06<21:55,  1.63s/it]
     36%|███████████████████████████▊                                                 | 456/1261 [28:36<2:17:01, 10.21s/it]
     36%|███████████████████████████▉                                                 | 457/1261 [28:37<1:36:56,  7.23s/it]
     36%|███████████████████████████▉                                                 | 458/1261 [28:37<1:08:32,  5.12s/it]
     36%|████████████████████████████▊                                                  | 459/1261 [28:38<52:03,  3.90s/it]
     36%|████████████████████████████▊                                                  | 460/1261 [28:39<39:09,  2.93s/it]
     37%|████████████████████████████▉                                                  | 461/1261 [28:39<28:27,  2.13s/it]
     37%|████████████████████████████▉                                                  | 462/1261 [28:40<23:44,  1.78s/it]
     37%|█████████████████████████████                                                  | 463/1261 [28:40<18:21,  1.38s/it]
     37%|████████████████████████████▎                                                | 464/1261 [29:10<2:12:35,  9.98s/it]
     37%|████████████████████████████▍                                                | 465/1261 [29:11<1:33:54,  7.08s/it]
     37%|████████████████████████████▍                                                | 466/1261 [29:11<1:06:24,  5.01s/it]
     37%|█████████████████████████████▎                                                 | 467/1261 [29:12<50:23,  3.81s/it]
     37%|█████████████████████████████▎                                                 | 468/1261 [29:12<37:38,  2.85s/it]
     37%|█████████████████████████████▍                                                 | 469/1261 [29:13<30:08,  2.28s/it]
     37%|█████████████████████████████▍                                                 | 470/1261 [29:14<22:01,  1.67s/it]
     37%|█████████████████████████████▌                                                 | 471/1261 [29:14<18:12,  1.38s/it]
     37%|████████████████████████████▊                                                | 472/1261 [29:45<2:11:50, 10.03s/it]
     38%|████████████████████████████▉                                                | 473/1261 [29:45<1:33:02,  7.08s/it]
     38%|████████████████████████████▉                                                | 474/1261 [29:45<1:06:07,  5.04s/it]
     38%|█████████████████████████████▊                                                 | 475/1261 [29:46<51:03,  3.90s/it]
     38%|█████████████████████████████▊                                                 | 476/1261 [29:47<37:25,  2.86s/it]
     38%|█████████████████████████████▉                                                 | 477/1261 [29:47<27:28,  2.10s/it]
     38%|█████████████████████████████▉                                                 | 478/1261 [29:48<22:46,  1.75s/it]
     38%|██████████████████████████████                                                 | 479/1261 [29:49<18:33,  1.42s/it]
     38%|█████████████████████████████▎                                               | 480/1261 [30:19<2:12:10, 10.15s/it]
     38%|█████████████████████████████▎                                               | 481/1261 [30:19<1:33:04,  7.16s/it]
     38%|█████████████████████████████▍                                               | 482/1261 [30:20<1:06:03,  5.09s/it]
     38%|██████████████████████████████▎                                                | 483/1261 [30:21<50:21,  3.88s/it]
     38%|██████████████████████████████▎                                                | 484/1261 [30:21<35:38,  2.75s/it]
     38%|██████████████████████████████▍                                                | 485/1261 [30:21<26:24,  2.04s/it]
     39%|██████████████████████████████▍                                                | 486/1261 [30:22<22:37,  1.75s/it]
     39%|██████████████████████████████▌                                                | 487/1261 [30:23<18:57,  1.47s/it]
     39%|█████████████████████████████▊                                               | 488/1261 [30:55<2:16:35, 10.60s/it]
     39%|█████████████████████████████▊                                               | 489/1261 [30:55<1:36:37,  7.51s/it]
     39%|█████████████████████████████▉                                               | 491/1261 [30:56<1:09:22,  5.41s/it]
     39%|██████████████████████████████▊                                                | 492/1261 [30:57<50:41,  3.95s/it]
     39%|██████████████████████████████▉                                                | 493/1261 [30:57<35:58,  2.81s/it]
     39%|██████████████████████████████▉                                                | 494/1261 [30:58<27:12,  2.13s/it]
     39%|███████████████████████████████                                                | 495/1261 [30:58<21:56,  1.72s/it]
     39%|██████████████████████████████▎                                              | 496/1261 [31:31<2:21:16, 11.08s/it]
     39%|██████████████████████████████▎                                              | 497/1261 [31:31<1:39:12,  7.79s/it]
     39%|██████████████████████████████▍                                              | 498/1261 [31:32<1:10:12,  5.52s/it]
     40%|███████████████████████████████▎                                               | 499/1261 [31:33<53:17,  4.20s/it]
     40%|███████████████████████████████▎                                               | 500/1261 [31:33<39:29,  3.11s/it]
     40%|███████████████████████████████▍                                               | 501/1261 [31:34<29:06,  2.30s/it]
     40%|███████████████████████████████▍                                               | 502/1261 [31:35<25:52,  2.05s/it]
     40%|███████████████████████████████▌                                               | 503/1261 [31:35<18:30,  1.47s/it]
     40%|██████████████████████████████▊                                              | 504/1261 [32:06<2:10:03, 10.31s/it]
     40%|██████████████████████████████▊                                              | 505/1261 [32:06<1:31:32,  7.27s/it]
     40%|██████████████████████████████▉                                              | 506/1261 [32:06<1:04:26,  5.12s/it]
     40%|███████████████████████████████▊                                               | 507/1261 [32:07<47:30,  3.78s/it]
     40%|███████████████████████████████▊                                               | 508/1261 [32:08<36:34,  2.91s/it]
     40%|███████████████████████████████▉                                               | 509/1261 [32:08<26:15,  2.10s/it]
     40%|███████████████████████████████▉                                               | 510/1261 [32:08<19:22,  1.55s/it]
     41%|████████████████████████████████                                               | 511/1261 [32:09<17:12,  1.38s/it]
     41%|███████████████████████████████▎                                             | 512/1261 [32:41<2:09:56, 10.41s/it]
     41%|███████████████████████████████▎                                             | 513/1261 [32:41<1:32:25,  7.41s/it]
     41%|███████████████████████████████▍                                             | 514/1261 [32:42<1:05:23,  5.25s/it]
     41%|████████████████████████████████▎                                              | 515/1261 [32:45<58:20,  4.69s/it]
     41%|████████████████████████████████▎                                              | 516/1261 [32:45<41:34,  3.35s/it]
     41%|████████████████████████████████▍                                              | 517/1261 [32:45<29:37,  2.39s/it]
     41%|████████████████████████████████▍                                              | 518/1261 [32:47<28:02,  2.26s/it]
     41%|████████████████████████████████▌                                              | 519/1261 [32:48<21:11,  1.71s/it]
     41%|███████████████████████████████▊                                             | 520/1261 [33:20<2:13:36, 10.82s/it]
     41%|███████████████████████████████▊                                             | 521/1261 [33:20<1:34:43,  7.68s/it]
     41%|███████████████████████████████▊                                             | 522/1261 [33:20<1:07:12,  5.46s/it]
     41%|████████████████████████████████▊                                              | 523/1261 [33:21<49:38,  4.04s/it]
     42%|████████████████████████████████▊                                              | 524/1261 [33:21<36:01,  2.93s/it]
     42%|████████████████████████████████▉                                              | 525/1261 [33:22<25:34,  2.09s/it]
     42%|████████████████████████████████▉                                              | 526/1261 [33:22<19:07,  1.56s/it]
     42%|█████████████████████████████████                                              | 527/1261 [33:23<16:13,  1.33s/it]
     42%|████████████████████████████████▏                                            | 528/1261 [33:53<2:02:29, 10.03s/it]
     42%|████████████████████████████████▎                                            | 529/1261 [33:53<1:26:40,  7.10s/it]
     42%|████████████████████████████████▎                                            | 530/1261 [33:54<1:01:51,  5.08s/it]
     42%|█████████████████████████████████▎                                             | 531/1261 [33:54<46:25,  3.82s/it]
     42%|█████████████████████████████████▎                                             | 532/1261 [33:55<33:56,  2.79s/it]
     42%|█████████████████████████████████▍                                             | 533/1261 [33:55<25:01,  2.06s/it]
     42%|█████████████████████████████████▍                                             | 534/1261 [33:56<20:11,  1.67s/it]
     42%|█████████████████████████████████▌                                             | 535/1261 [33:57<15:59,  1.32s/it]
     43%|████████████████████████████████▋                                            | 536/1261 [34:30<2:12:55, 11.00s/it]
     43%|████████████████████████████████▊                                            | 537/1261 [34:30<1:34:07,  7.80s/it]
     43%|████████████████████████████████▊                                            | 538/1261 [34:31<1:06:09,  5.49s/it]
     43%|█████████████████████████████████▊                                             | 539/1261 [34:32<50:05,  4.16s/it]
     43%|█████████████████████████████████▊                                             | 540/1261 [34:32<37:15,  3.10s/it]
     43%|█████████████████████████████████▉                                             | 541/1261 [34:32<26:39,  2.22s/it]
     43%|█████████████████████████████████▉                                             | 542/1261 [34:33<22:28,  1.88s/it]
     43%|██████████████████████████████████                                             | 543/1261 [34:34<16:08,  1.35s/it]
     43%|█████████████████████████████████▏                                           | 544/1261 [35:04<2:00:15, 10.06s/it]
     43%|█████████████████████████████████▎                                           | 545/1261 [35:04<1:24:55,  7.12s/it]
     43%|█████████████████████████████████▎                                           | 546/1261 [35:04<1:00:02,  5.04s/it]
     43%|██████████████████████████████████▎                                            | 547/1261 [35:05<43:55,  3.69s/it]
     43%|██████████████████████████████████▎                                            | 548/1261 [35:06<32:54,  2.77s/it]
     44%|██████████████████████████████████▍                                            | 550/1261 [35:06<23:14,  1.96s/it]
     44%|██████████████████████████████████▌                                            | 551/1261 [35:06<18:28,  1.56s/it]
     44%|█████████████████████████████████▋                                           | 552/1261 [35:36<1:57:01,  9.90s/it]
     44%|█████████████████████████████████▊                                           | 553/1261 [35:36<1:22:38,  7.00s/it]
     44%|██████████████████████████████████▋                                            | 554/1261 [35:36<58:22,  4.95s/it]
     44%|██████████████████████████████████▊                                            | 555/1261 [35:37<43:33,  3.70s/it]
     44%|██████████████████████████████████▊                                            | 556/1261 [35:37<31:48,  2.71s/it]
     44%|██████████████████████████████████▉                                            | 557/1261 [35:38<24:03,  2.05s/it]
     44%|██████████████████████████████████▉                                            | 558/1261 [35:38<18:04,  1.54s/it]
     44%|███████████████████████████████████                                            | 559/1261 [35:39<15:41,  1.34s/it]
     44%|██████████████████████████████████▏                                          | 560/1261 [36:11<2:01:46, 10.42s/it]
     44%|██████████████████████████████████▎                                          | 561/1261 [36:11<1:25:43,  7.35s/it]
     45%|██████████████████████████████████▎                                          | 562/1261 [36:11<1:00:40,  5.21s/it]
     45%|███████████████████████████████████▎                                           | 563/1261 [36:12<44:43,  3.84s/it]
     45%|███████████████████████████████████▎                                           | 564/1261 [36:12<33:33,  2.89s/it]
     45%|███████████████████████████████████▍                                           | 565/1261 [36:13<25:32,  2.20s/it]
     45%|███████████████████████████████████▍                                           | 566/1261 [36:13<18:29,  1.60s/it]
     45%|███████████████████████████████████▌                                           | 567/1261 [36:14<15:53,  1.37s/it]
     45%|██████████████████████████████████▋                                          | 568/1261 [36:44<1:53:23,  9.82s/it]
     45%|██████████████████████████████████▋                                          | 569/1261 [36:44<1:20:20,  6.97s/it]
     45%|███████████████████████████████████▋                                           | 570/1261 [36:44<56:58,  4.95s/it]
     45%|███████████████████████████████████▊                                           | 571/1261 [36:45<43:48,  3.81s/it]
     45%|███████████████████████████████████▊                                           | 572/1261 [36:46<31:42,  2.76s/it]
     45%|███████████████████████████████████▉                                           | 573/1261 [36:46<23:54,  2.08s/it]
     46%|███████████████████████████████████▉                                           | 574/1261 [36:47<18:38,  1.63s/it]
     46%|████████████████████████████████████                                           | 575/1261 [36:47<15:46,  1.38s/it]
     46%|███████████████████████████████████▏                                         | 576/1261 [37:18<1:55:44, 10.14s/it]
     46%|███████████████████████████████████▏                                         | 577/1261 [37:18<1:21:47,  7.18s/it]
     46%|████████████████████████████████████▏                                          | 578/1261 [37:18<57:42,  5.07s/it]
     46%|████████████████████████████████████▎                                          | 579/1261 [37:19<43:22,  3.82s/it]
     46%|████████████████████████████████████▎                                          | 580/1261 [37:20<33:12,  2.93s/it]
     46%|████████████████████████████████████▍                                          | 581/1261 [37:20<23:47,  2.10s/it]
     46%|████████████████████████████████████▌                                          | 583/1261 [37:22<19:29,  1.73s/it]
     46%|███████████████████████████████████▋                                         | 584/1261 [37:54<2:01:50, 10.80s/it]
     46%|███████████████████████████████████▋                                         | 585/1261 [37:54<1:25:54,  7.63s/it]
     46%|███████████████████████████████████▊                                         | 586/1261 [37:54<1:00:48,  5.41s/it]
     47%|████████████████████████████████████▊                                          | 587/1261 [37:55<45:47,  4.08s/it]
     47%|████████████████████████████████████▊                                          | 588/1261 [37:56<34:15,  3.05s/it]
     47%|████████████████████████████████████▉                                          | 589/1261 [37:56<25:20,  2.26s/it]
     47%|████████████████████████████████████▉                                          | 590/1261 [37:57<18:56,  1.69s/it]
     47%|█████████████████████████████████████                                          | 591/1261 [37:57<14:40,  1.31s/it]
     47%|████████████████████████████████████▏                                        | 592/1261 [38:27<1:49:44,  9.84s/it]
     47%|████████████████████████████████████▏                                        | 593/1261 [38:27<1:17:22,  6.95s/it]
     47%|█████████████████████████████████████▏                                         | 594/1261 [38:28<55:19,  4.98s/it]
     47%|█████████████████████████████████████▎                                         | 595/1261 [38:29<41:40,  3.75s/it]
     47%|█████████████████████████████████████▎                                         | 596/1261 [38:29<30:03,  2.71s/it]
     47%|█████████████████████████████████████▍                                         | 597/1261 [38:29<21:53,  1.98s/it]
     47%|█████████████████████████████████████▍                                         | 598/1261 [38:30<17:58,  1.63s/it]
     48%|█████████████████████████████████████▌                                         | 599/1261 [38:30<14:16,  1.29s/it]
     48%|████████████████████████████████████▋                                        | 600/1261 [39:00<1:49:01,  9.90s/it]
     48%|████████████████████████████████████▋                                        | 601/1261 [39:01<1:17:16,  7.03s/it]
     48%|█████████████████████████████████████▋                                         | 602/1261 [39:01<54:34,  4.97s/it]
     48%|█████████████████████████████████████▊                                         | 603/1261 [39:02<41:02,  3.74s/it]
     48%|█████████████████████████████████████▊                                         | 604/1261 [39:02<29:54,  2.73s/it]
     48%|█████████████████████████████████████▉                                         | 605/1261 [39:03<22:53,  2.09s/it]
     48%|█████████████████████████████████████▉                                         | 606/1261 [39:03<17:02,  1.56s/it]
     48%|██████████████████████████████████████                                         | 607/1261 [39:03<12:56,  1.19s/it]
     48%|█████████████████████████████████████▏                                       | 608/1261 [39:33<1:46:27,  9.78s/it]
     48%|█████████████████████████████████████▏                                       | 609/1261 [39:33<1:14:58,  6.90s/it]
     48%|██████████████████████████████████████▏                                        | 610/1261 [39:34<53:11,  4.90s/it]
     48%|██████████████████████████████████████▎                                        | 611/1261 [39:35<40:46,  3.76s/it]
     49%|██████████████████████████████████████▎                                        | 612/1261 [39:36<31:48,  2.94s/it]
     49%|██████████████████████████████████████▍                                        | 613/1261 [39:36<22:54,  2.12s/it]
     49%|██████████████████████████████████████▍                                        | 614/1261 [39:37<19:03,  1.77s/it]
     49%|██████████████████████████████████████▌                                        | 615/1261 [39:37<14:10,  1.32s/it]
     49%|█████████████████████████████████████▌                                       | 616/1261 [40:09<1:51:34, 10.38s/it]
     49%|█████████████████████████████████████▋                                       | 617/1261 [40:09<1:18:50,  7.35s/it]
     49%|██████████████████████████████████████▋                                        | 618/1261 [40:09<55:37,  5.19s/it]
     49%|██████████████████████████████████████▊                                        | 619/1261 [40:11<43:57,  4.11s/it]
     49%|██████████████████████████████████████▉                                        | 621/1261 [40:12<32:10,  3.02s/it]
     49%|██████████████████████████████████████▉                                        | 622/1261 [40:12<25:12,  2.37s/it]
     49%|███████████████████████████████████████                                        | 623/1261 [40:13<19:32,  1.84s/it]
     49%|██████████████████████████████████████                                       | 624/1261 [40:44<1:52:25, 10.59s/it]
     50%|██████████████████████████████████████▏                                      | 625/1261 [40:44<1:19:09,  7.47s/it]
     50%|███████████████████████████████████████▏                                       | 626/1261 [40:44<55:46,  5.27s/it]
     50%|███████████████████████████████████████▎                                       | 627/1261 [40:46<43:50,  4.15s/it]
     50%|███████████████████████████████████████▎                                       | 628/1261 [40:46<30:59,  2.94s/it]
     50%|███████████████████████████████████████▍                                       | 629/1261 [40:46<22:02,  2.09s/it]
     50%|███████████████████████████████████████▍                                       | 630/1261 [40:47<19:18,  1.84s/it]
     50%|███████████████████████████████████████▌                                       | 631/1261 [40:48<15:20,  1.46s/it]
     50%|██████████████████████████████████████▌                                      | 632/1261 [41:17<1:40:29,  9.59s/it]
     50%|██████████████████████████████████████▋                                      | 633/1261 [41:17<1:10:59,  6.78s/it]
     50%|███████████████████████████████████████▋                                       | 634/1261 [41:17<50:01,  4.79s/it]
     50%|███████████████████████████████████████▊                                       | 635/1261 [41:18<39:58,  3.83s/it]
     50%|███████████████████████████████████████▊                                       | 636/1261 [41:19<28:20,  2.72s/it]
     51%|███████████████████████████████████████▉                                       | 637/1261 [41:19<20:15,  1.95s/it]
     51%|███████████████████████████████████████▉                                       | 638/1261 [41:20<17:49,  1.72s/it]
     51%|████████████████████████████████████████                                       | 639/1261 [41:20<14:06,  1.36s/it]
     51%|███████████████████████████████████████                                      | 640/1261 [41:47<1:31:37,  8.85s/it]
     51%|███████████████████████████████████████▏                                     | 641/1261 [41:47<1:04:37,  6.25s/it]
     51%|████████████████████████████████████████▏                                      | 642/1261 [41:47<45:45,  4.44s/it]
     51%|████████████████████████████████████████▎                                      | 643/1261 [41:48<35:34,  3.45s/it]
     51%|████████████████████████████████████████▎                                      | 644/1261 [41:49<25:39,  2.49s/it]
     51%|████████████████████████████████████████▍                                      | 645/1261 [41:49<19:01,  1.85s/it]
     51%|████████████████████████████████████████▍                                      | 646/1261 [41:50<15:49,  1.54s/it]
     51%|████████████████████████████████████████▌                                      | 647/1261 [41:50<12:40,  1.24s/it]
     51%|███████████████████████████████████████▌                                     | 648/1261 [42:20<1:39:19,  9.72s/it]
     51%|███████████████████████████████████████▋                                     | 649/1261 [42:20<1:10:02,  6.87s/it]
     52%|████████████████████████████████████████▋                                      | 650/1261 [42:20<49:32,  4.86s/it]
     52%|████████████████████████████████████████▊                                      | 651/1261 [42:21<38:14,  3.76s/it]
     52%|████████████████████████████████████████▉                                      | 653/1261 [42:22<27:51,  2.75s/it]
     52%|████████████████████████████████████████▉                                      | 654/1261 [42:23<22:25,  2.22s/it]
     52%|█████████████████████████████████████████                                      | 655/1261 [42:24<16:52,  1.67s/it]
     52%|████████████████████████████████████████                                     | 656/1261 [42:55<1:46:39, 10.58s/it]
     52%|████████████████████████████████████████                                     | 657/1261 [42:55<1:15:15,  7.48s/it]
     52%|█████████████████████████████████████████▏                                     | 658/1261 [42:55<53:01,  5.28s/it]
     52%|█████████████████████████████████████████▎                                     | 659/1261 [42:56<40:21,  4.02s/it]
     52%|█████████████████████████████████████████▎                                     | 660/1261 [42:57<29:16,  2.92s/it]
     52%|█████████████████████████████████████████▍                                     | 661/1261 [42:57<22:17,  2.23s/it]
     52%|█████████████████████████████████████████▍                                     | 662/1261 [42:58<18:22,  1.84s/it]
     53%|█████████████████████████████████████████▌                                     | 663/1261 [42:59<14:45,  1.48s/it]
     53%|████████████████████████████████████████▌                                    | 664/1261 [43:29<1:41:29, 10.20s/it]
     53%|████████████████████████████████████████▌                                    | 665/1261 [43:30<1:12:08,  7.26s/it]
     53%|█████████████████████████████████████████▋                                     | 666/1261 [43:30<50:53,  5.13s/it]
     53%|█████████████████████████████████████████▊                                     | 667/1261 [43:33<45:20,  4.58s/it]
     53%|█████████████████████████████████████████▊                                     | 668/1261 [43:34<32:08,  3.25s/it]
     53%|█████████████████████████████████████████▉                                     | 669/1261 [43:34<23:32,  2.39s/it]
     53%|█████████████████████████████████████████▉                                     | 670/1261 [43:35<19:16,  1.96s/it]
     53%|██████████████████████████████████████████                                     | 671/1261 [43:35<15:14,  1.55s/it]
     53%|█████████████████████████████████████████                                    | 672/1261 [44:06<1:40:52, 10.28s/it]
     53%|█████████████████████████████████████████                                    | 673/1261 [44:06<1:11:30,  7.30s/it]
     54%|██████████████████████████████████████████▎                                    | 675/1261 [44:08<51:40,  5.29s/it]
     54%|██████████████████████████████████████████▎                                    | 676/1261 [44:08<36:54,  3.79s/it]
     54%|██████████████████████████████████████████▍                                    | 677/1261 [44:08<26:57,  2.77s/it]
     54%|██████████████████████████████████████████▍                                    | 678/1261 [44:09<20:29,  2.11s/it]
     54%|██████████████████████████████████████████▌                                    | 679/1261 [44:10<16:10,  1.67s/it]
     54%|█████████████████████████████████████████▌                                   | 680/1261 [44:41<1:43:29, 10.69s/it]
     54%|█████████████████████████████████████████▌                                   | 681/1261 [44:42<1:13:24,  7.59s/it]
     54%|██████████████████████████████████████████▋                                    | 682/1261 [44:42<51:37,  5.35s/it]
     54%|██████████████████████████████████████████▊                                    | 683/1261 [44:43<38:24,  3.99s/it]
     54%|██████████████████████████████████████████▊                                    | 684/1261 [44:43<29:27,  3.06s/it]
     54%|██████████████████████████████████████████▉                                    | 685/1261 [44:44<22:01,  2.29s/it]
     54%|██████████████████████████████████████████▉                                    | 686/1261 [44:45<17:28,  1.82s/it]
     54%|███████████████████████████████████████████                                    | 687/1261 [44:45<13:20,  1.40s/it]
     55%|██████████████████████████████████████████                                   | 688/1261 [45:14<1:31:54,  9.62s/it]
     55%|██████████████████████████████████████████                                   | 689/1261 [45:14<1:04:56,  6.81s/it]
     55%|███████████████████████████████████████████▏                                   | 690/1261 [45:15<46:27,  4.88s/it]
     55%|███████████████████████████████████████████▎                                   | 691/1261 [45:15<34:55,  3.68s/it]
     55%|███████████████████████████████████████████▎                                   | 692/1261 [45:16<25:18,  2.67s/it]
     55%|███████████████████████████████████████████▍                                   | 693/1261 [45:17<20:02,  2.12s/it]
     55%|███████████████████████████████████████████▍                                   | 694/1261 [45:17<15:39,  1.66s/it]
     55%|███████████████████████████████████████████▌                                   | 695/1261 [45:18<14:06,  1.49s/it]
     55%|██████████████████████████████████████████▍                                  | 696/1261 [45:49<1:36:52, 10.29s/it]
     55%|██████████████████████████████████████████▌                                  | 697/1261 [45:49<1:08:36,  7.30s/it]
     55%|███████████████████████████████████████████▋                                   | 698/1261 [45:50<48:43,  5.19s/it]
     55%|███████████████████████████████████████████▊                                   | 699/1261 [45:50<36:11,  3.86s/it]
     56%|███████████████████████████████████████████▊                                   | 700/1261 [45:51<25:52,  2.77s/it]
     56%|███████████████████████████████████████████▉                                   | 701/1261 [45:51<18:54,  2.03s/it]
     56%|███████████████████████████████████████████▉                                   | 702/1261 [45:52<15:20,  1.65s/it]
     56%|████████████████████████████████████████████                                   | 703/1261 [45:52<11:32,  1.24s/it]
     56%|██████████████████████████████████████████▉                                  | 704/1261 [46:23<1:34:00, 10.13s/it]
     56%|███████████████████████████████████████████                                  | 705/1261 [46:23<1:06:32,  7.18s/it]
     56%|████████████████████████████████████████████▏                                  | 706/1261 [46:23<47:10,  5.10s/it]
     56%|████████████████████████████████████████████▎                                  | 707/1261 [46:24<35:22,  3.83s/it]
     56%|████████████████████████████████████████████▎                                  | 708/1261 [46:25<25:30,  2.77s/it]
     56%|████████████████████████████████████████████▍                                  | 709/1261 [46:25<19:06,  2.08s/it]
     56%|████████████████████████████████████████████▍                                  | 710/1261 [46:25<14:03,  1.53s/it]
     56%|████████████████████████████████████████████▌                                  | 711/1261 [46:26<10:52,  1.19s/it]
     56%|███████████████████████████████████████████▍                                 | 712/1261 [46:56<1:29:44,  9.81s/it]
     57%|███████████████████████████████████████████▌                                 | 713/1261 [46:56<1:03:22,  6.94s/it]
     57%|████████████████████████████████████████████▋                                  | 714/1261 [46:56<44:54,  4.93s/it]
     57%|████████████████████████████████████████████▊                                  | 715/1261 [46:56<32:12,  3.54s/it]
     57%|████████████████████████████████████████████▉                                  | 717/1261 [46:57<22:48,  2.52s/it]
     57%|████████████████████████████████████████████▉                                  | 718/1261 [46:57<16:59,  1.88s/it]
     57%|█████████████████████████████████████████████                                  | 719/1261 [46:58<13:44,  1.52s/it]
     57%|███████████████████████████████████████████▉                                 | 720/1261 [47:27<1:27:48,  9.74s/it]
     57%|████████████████████████████████████████████                                 | 721/1261 [47:27<1:01:40,  6.85s/it]
     57%|█████████████████████████████████████████████▏                                 | 722/1261 [47:27<43:41,  4.86s/it]
     57%|█████████████████████████████████████████████▎                                 | 723/1261 [47:28<33:04,  3.69s/it]
     57%|█████████████████████████████████████████████▎                                 | 724/1261 [47:28<23:48,  2.66s/it]
     57%|█████████████████████████████████████████████▍                                 | 725/1261 [47:28<17:08,  1.92s/it]
     58%|█████████████████████████████████████████████▍                                 | 726/1261 [47:29<14:35,  1.64s/it]
     58%|█████████████████████████████████████████████▌                                 | 727/1261 [47:30<10:49,  1.22s/it]
     58%|████████████████████████████████████████████▍                                | 728/1261 [47:59<1:26:34,  9.75s/it]
     58%|████████████████████████████████████████████▌                                | 729/1261 [47:59<1:01:17,  6.91s/it]
     58%|█████████████████████████████████████████████▋                                 | 730/1261 [48:00<43:31,  4.92s/it]
     58%|█████████████████████████████████████████████▊                                 | 731/1261 [48:00<32:17,  3.66s/it]
     58%|█████████████████████████████████████████████▊                                 | 732/1261 [48:01<23:44,  2.69s/it]
     58%|█████████████████████████████████████████████▉                                 | 733/1261 [48:01<17:34,  2.00s/it]
     58%|█████████████████████████████████████████████▉                                 | 734/1261 [48:01<12:46,  1.45s/it]
     58%|██████████████████████████████████████████████                                 | 735/1261 [48:02<10:52,  1.24s/it]
     58%|████████████████████████████████████████████▉                                | 736/1261 [48:35<1:33:19, 10.67s/it]
     58%|█████████████████████████████████████████████                                | 737/1261 [48:35<1:05:31,  7.50s/it]
     59%|██████████████████████████████████████████████▏                                | 738/1261 [48:35<46:05,  5.29s/it]
     59%|██████████████████████████████████████████████▎                                | 739/1261 [48:36<33:52,  3.89s/it]
     59%|██████████████████████████████████████████████▎                                | 740/1261 [48:36<24:37,  2.84s/it]
     59%|██████████████████████████████████████████████▍                                | 741/1261 [48:36<17:48,  2.06s/it]
     59%|██████████████████████████████████████████████▍                                | 742/1261 [48:37<14:01,  1.62s/it]
     59%|██████████████████████████████████████████████▌                                | 743/1261 [48:37<10:36,  1.23s/it]
     59%|█████████████████████████████████████████████▍                               | 744/1261 [49:09<1:29:25, 10.38s/it]
     59%|█████████████████████████████████████████████▍                               | 745/1261 [49:09<1:03:06,  7.34s/it]
     59%|██████████████████████████████████████████████▋                                | 746/1261 [49:10<44:53,  5.23s/it]
     59%|██████████████████████████████████████████████▊                                | 747/1261 [49:10<33:14,  3.88s/it]
     59%|██████████████████████████████████████████████▊                                | 748/1261 [49:11<24:17,  2.84s/it]
     59%|██████████████████████████████████████████████▉                                | 749/1261 [49:11<17:18,  2.03s/it]
     59%|██████████████████████████████████████████████▉                                | 750/1261 [49:11<13:31,  1.59s/it]
     60%|███████████████████████████████████████████████                                | 752/1261 [49:42<48:47,  5.75s/it]
     60%|███████████████████████████████████████████████▏                               | 753/1261 [49:43<34:40,  4.10s/it]
     60%|███████████████████████████████████████████████▏                               | 754/1261 [49:43<25:04,  2.97s/it]
     60%|███████████████████████████████████████████████▎                               | 755/1261 [49:44<20:25,  2.42s/it]
     60%|███████████████████████████████████████████████▎                               | 756/1261 [49:45<17:16,  2.05s/it]
     60%|███████████████████████████████████████████████▍                               | 757/1261 [49:45<12:27,  1.48s/it]
     60%|███████████████████████████████████████████████▍                               | 758/1261 [49:46<09:14,  1.10s/it]
     60%|███████████████████████████████████████████████▌                               | 759/1261 [49:46<08:12,  1.02it/s]
     60%|██████████████████████████████████████████████▍                              | 760/1261 [50:19<1:27:28, 10.48s/it]
     60%|██████████████████████████████████████████████▍                              | 761/1261 [50:19<1:01:31,  7.38s/it]
     60%|███████████████████████████████████████████████▋                               | 762/1261 [50:19<43:27,  5.23s/it]
     61%|███████████████████████████████████████████████▊                               | 763/1261 [50:20<31:55,  3.85s/it]
     61%|███████████████████████████████████████████████▊                               | 764/1261 [50:21<24:28,  2.95s/it]
     61%|███████████████████████████████████████████████▉                               | 765/1261 [50:21<17:31,  2.12s/it]
     61%|███████████████████████████████████████████████▉                               | 766/1261 [50:22<13:57,  1.69s/it]
     61%|████████████████████████████████████████████████                               | 767/1261 [50:22<11:22,  1.38s/it]
     61%|██████████████████████████████████████████████▉                              | 768/1261 [50:52<1:20:41,  9.82s/it]
     61%|████████████████████████████████████████████████▏                              | 769/1261 [50:52<57:13,  6.98s/it]
     61%|████████████████████████████████████████████████▏                              | 770/1261 [50:53<40:48,  4.99s/it]
     61%|████████████████████████████████████████████████▎                              | 771/1261 [50:53<30:29,  3.73s/it]
     61%|████████████████████████████████████████████████▎                              | 772/1261 [50:54<22:50,  2.80s/it]
     61%|████████████████████████████████████████████████▍                              | 773/1261 [50:54<16:46,  2.06s/it]
     61%|████████████████████████████████████████████████▍                              | 774/1261 [50:55<13:10,  1.62s/it]
     61%|████████████████████████████████████████████████▌                              | 775/1261 [50:55<10:13,  1.26s/it]
     62%|███████████████████████████████████████████████▍                             | 776/1261 [51:25<1:19:45,  9.87s/it]
     62%|████████████████████████████████████████████████▋                              | 777/1261 [51:25<56:15,  6.97s/it]
     62%|████████████████████████████████████████████████▋                              | 778/1261 [51:26<39:54,  4.96s/it]
     62%|████████████████████████████████████████████████▊                              | 779/1261 [51:26<29:34,  3.68s/it]
     62%|████████████████████████████████████████████████▊                              | 780/1261 [51:27<21:29,  2.68s/it]
     62%|████████████████████████████████████████████████▉                              | 781/1261 [51:28<17:35,  2.20s/it]
     62%|████████████████████████████████████████████████▉                              | 782/1261 [51:28<12:55,  1.62s/it]
     62%|█████████████████████████████████████████████████                              | 783/1261 [51:29<09:57,  1.25s/it]
     62%|███████████████████████████████████████████████▊                             | 784/1261 [51:59<1:19:10,  9.96s/it]
     62%|█████████████████████████████████████████████████▏                             | 785/1261 [51:59<55:35,  7.01s/it]
     62%|█████████████████████████████████████████████████▎                             | 787/1261 [51:59<39:05,  4.95s/it]
     62%|█████████████████████████████████████████████████▎                             | 788/1261 [52:00<28:01,  3.55s/it]
     63%|█████████████████████████████████████████████████▍                             | 789/1261 [52:00<21:46,  2.77s/it]
     63%|█████████████████████████████████████████████████▍                             | 790/1261 [52:01<15:57,  2.03s/it]
     63%|█████████████████████████████████████████████████▌                             | 791/1261 [52:02<15:15,  1.95s/it]
     63%|████████████████████████████████████████████████▎                            | 792/1261 [52:33<1:22:34, 10.56s/it]
     63%|█████████████████████████████████████████████████▋                             | 793/1261 [52:34<58:27,  7.49s/it]
     63%|█████████████████████████████████████████████████▋                             | 794/1261 [52:34<41:19,  5.31s/it]
     63%|█████████████████████████████████████████████████▊                             | 795/1261 [52:37<37:30,  4.83s/it]
     63%|█████████████████████████████████████████████████▊                             | 796/1261 [52:38<26:48,  3.46s/it]
     63%|█████████████████████████████████████████████████▉                             | 797/1261 [52:39<20:45,  2.68s/it]
     63%|█████████████████████████████████████████████████▉                             | 798/1261 [52:39<15:23,  1.99s/it]
     63%|██████████████████████████████████████████████████                             | 799/1261 [52:39<11:41,  1.52s/it]
     63%|████████████████████████████████████████████████▊                            | 800/1261 [53:09<1:15:37,  9.84s/it]
     64%|██████████████████████████████████████████████████▏                            | 801/1261 [53:09<53:35,  6.99s/it]
     64%|██████████████████████████████████████████████████▏                            | 802/1261 [53:09<37:53,  4.95s/it]
     64%|██████████████████████████████████████████████████▎                            | 803/1261 [53:10<28:34,  3.74s/it]
     64%|██████████████████████████████████████████████████▎                            | 804/1261 [53:11<21:26,  2.81s/it]
     64%|██████████████████████████████████████████████████▍                            | 805/1261 [53:11<15:36,  2.05s/it]
     64%|██████████████████████████████████████████████████▍                            | 806/1261 [53:12<12:25,  1.64s/it]
     64%|██████████████████████████████████████████████████▌                            | 807/1261 [53:12<09:48,  1.30s/it]
     64%|█████████████████████████████████████████████████▎                           | 808/1261 [53:43<1:17:21, 10.25s/it]
     64%|██████████████████████████████████████████████████▋                            | 809/1261 [53:44<54:54,  7.29s/it]
     64%|██████████████████████████████████████████████████▋                            | 810/1261 [53:44<38:46,  5.16s/it]
     64%|██████████████████████████████████████████████████▊                            | 811/1261 [53:45<29:07,  3.88s/it]
     64%|██████████████████████████████████████████████████▊                            | 812/1261 [53:45<21:36,  2.89s/it]
     64%|██████████████████████████████████████████████████▉                            | 813/1261 [53:46<15:41,  2.10s/it]
     65%|██████████████████████████████████████████████████▉                            | 814/1261 [53:46<12:04,  1.62s/it]
     65%|███████████████████████████████████████████████████                            | 815/1261 [53:47<09:22,  1.26s/it]
     65%|█████████████████████████████████████████████████▊                           | 816/1261 [54:20<1:20:30, 10.86s/it]
     65%|███████████████████████████████████████████████████▏                           | 817/1261 [54:20<56:40,  7.66s/it]
     65%|███████████████████████████████████████████████████▏                           | 818/1261 [54:20<39:51,  5.40s/it]
     65%|███████████████████████████████████████████████████▎                           | 819/1261 [54:21<29:42,  4.03s/it]
     65%|███████████████████████████████████████████████████▎                           | 820/1261 [54:21<21:37,  2.94s/it]
     65%|███████████████████████████████████████████████████▍                           | 821/1261 [54:22<16:10,  2.20s/it]
     65%|███████████████████████████████████████████████████▍                           | 822/1261 [54:23<12:56,  1.77s/it]
     65%|███████████████████████████████████████████████████▌                           | 823/1261 [54:23<09:31,  1.31s/it]
     65%|██████████████████████████████████████████████████▎                          | 824/1261 [54:54<1:14:53, 10.28s/it]
     65%|███████████████████████████████████████████████████▋                           | 825/1261 [54:54<52:51,  7.27s/it]
     66%|███████████████████████████████████████████████████▋                           | 826/1261 [54:55<37:36,  5.19s/it]
     66%|███████████████████████████████████████████████████▊                           | 827/1261 [54:56<28:14,  3.90s/it]
     66%|███████████████████████████████████████████████████▊                           | 828/1261 [54:56<20:23,  2.83s/it]
     66%|███████████████████████████████████████████████████▉                           | 829/1261 [54:56<15:36,  2.17s/it]
     66%|███████████████████████████████████████████████████▉                           | 830/1261 [54:57<11:16,  1.57s/it]
     66%|████████████████████████████████████████████████████                           | 831/1261 [54:57<08:49,  1.23s/it]
     66%|██████████████████████████████████████████████████▊                          | 832/1261 [55:25<1:05:48,  9.20s/it]
     66%|████████████████████████████████████████████████████▏                          | 833/1261 [55:25<46:37,  6.54s/it]
     66%|████████████████████████████████████████████████████▏                          | 834/1261 [55:25<32:54,  4.62s/it]
     66%|████████████████████████████████████████████████████▎                          | 835/1261 [55:26<24:11,  3.41s/it]
     66%|████████████████████████████████████████████████████▎                          | 836/1261 [55:26<18:02,  2.55s/it]
     66%|████████████████████████████████████████████████████▍                          | 837/1261 [55:27<13:42,  1.94s/it]
     66%|████████████████████████████████████████████████████▍                          | 838/1261 [55:27<10:17,  1.46s/it]
     67%|████████████████████████████████████████████████████▌                          | 839/1261 [55:28<09:36,  1.37s/it]
     67%|███████████████████████████████████████████████████▎                         | 840/1261 [56:00<1:12:21, 10.31s/it]
     67%|████████████████████████████████████████████████████▋                          | 841/1261 [56:00<51:32,  7.36s/it]
     67%|████████████████████████████████████████████████████▊                          | 842/1261 [56:00<36:20,  5.20s/it]
     67%|████████████████████████████████████████████████████▊                          | 843/1261 [56:01<27:02,  3.88s/it]
     67%|████████████████████████████████████████████████████▉                          | 844/1261 [56:01<19:34,  2.82s/it]
     67%|█████████████████████████████████████████████████████                          | 846/1261 [56:02<13:49,  2.00s/it]
     67%|█████████████████████████████████████████████████████                          | 847/1261 [56:02<10:14,  1.48s/it]
     67%|███████████████████████████████████████████████████▊                         | 848/1261 [56:34<1:14:19, 10.80s/it]
     67%|█████████████████████████████████████████████████████▏                         | 849/1261 [56:35<52:24,  7.63s/it]
     67%|█████████████████████████████████████████████████████▎                         | 850/1261 [56:35<36:59,  5.40s/it]
     67%|█████████████████████████████████████████████████████▎                         | 851/1261 [56:36<27:40,  4.05s/it]
     68%|█████████████████████████████████████████████████████▍                         | 852/1261 [56:36<20:04,  2.95s/it]
     68%|█████████████████████████████████████████████████████▍                         | 853/1261 [56:37<14:54,  2.19s/it]
     68%|█████████████████████████████████████████████████████▌                         | 854/1261 [56:37<11:49,  1.74s/it]
     68%|█████████████████████████████████████████████████████▌                         | 855/1261 [56:38<09:19,  1.38s/it]
     68%|████████████████████████████████████████████████████▎                        | 856/1261 [57:09<1:09:23, 10.28s/it]
     68%|█████████████████████████████████████████████████████▋                         | 857/1261 [57:09<48:57,  7.27s/it]
     68%|█████████████████████████████████████████████████████▊                         | 858/1261 [57:09<34:38,  5.16s/it]
     68%|█████████████████████████████████████████████████████▊                         | 859/1261 [57:10<25:46,  3.85s/it]
     68%|█████████████████████████████████████████████████████▉                         | 860/1261 [57:11<19:44,  2.95s/it]
     68%|█████████████████████████████████████████████████████▉                         | 861/1261 [57:11<14:13,  2.13s/it]
     68%|██████████████████████████████████████████████████████                         | 862/1261 [57:12<12:07,  1.82s/it]
     68%|██████████████████████████████████████████████████████                         | 863/1261 [57:13<09:05,  1.37s/it]
     69%|████████████████████████████████████████████████████▊                        | 864/1261 [57:43<1:05:43,  9.93s/it]
     69%|██████████████████████████████████████████████████████▏                        | 865/1261 [57:43<46:16,  7.01s/it]
     69%|██████████████████████████████████████████████████████▎                        | 866/1261 [57:43<32:42,  4.97s/it]
     69%|██████████████████████████████████████████████████████▎                        | 867/1261 [57:44<25:18,  3.85s/it]
     69%|██████████████████████████████████████████████████████▍                        | 868/1261 [57:45<20:11,  3.08s/it]
     69%|██████████████████████████████████████████████████████▍                        | 869/1261 [57:46<14:48,  2.27s/it]
     69%|██████████████████████████████████████████████████████▌                        | 870/1261 [57:46<10:55,  1.68s/it]
     69%|██████████████████████████████████████████████████████▌                        | 871/1261 [57:47<09:50,  1.51s/it]
     69%|█████████████████████████████████████████████████████▏                       | 872/1261 [58:16<1:02:10,  9.59s/it]
     69%|██████████████████████████████████████████████████████▋                        | 873/1261 [58:16<44:06,  6.82s/it]
     69%|██████████████████████████████████████████████████████▊                        | 874/1261 [58:16<31:19,  4.86s/it]
     69%|██████████████████████████████████████████████████████▊                        | 875/1261 [58:17<23:06,  3.59s/it]
     69%|██████████████████████████████████████████████████████▉                        | 876/1261 [58:17<16:38,  2.59s/it]
     70%|██████████████████████████████████████████████████████▉                        | 877/1261 [58:18<12:18,  1.92s/it]
     70%|███████████████████████████████████████████████████████                        | 878/1261 [58:18<09:53,  1.55s/it]
     70%|███████████████████████████████████████████████████████                        | 879/1261 [58:19<07:29,  1.18s/it]
     70%|█████████████████████████████████████████████████████▋                       | 880/1261 [58:50<1:05:00, 10.24s/it]
     70%|███████████████████████████████████████████████████████▏                       | 881/1261 [58:50<45:52,  7.24s/it]
     70%|███████████████████████████████████████████████████████▎                       | 882/1261 [58:50<32:29,  5.14s/it]
     70%|███████████████████████████████████████████████████████▎                       | 883/1261 [58:51<24:27,  3.88s/it]
     70%|███████████████████████████████████████████████████████▍                       | 884/1261 [58:52<17:57,  2.86s/it]
     70%|███████████████████████████████████████████████████████▍                       | 885/1261 [58:52<12:43,  2.03s/it]
     70%|███████████████████████████████████████████████████████▌                       | 886/1261 [58:53<10:10,  1.63s/it]
     70%|███████████████████████████████████████████████████████▌                       | 887/1261 [58:53<08:13,  1.32s/it]
     70%|██████████████████████████████████████████████████████▏                      | 888/1261 [59:23<1:01:06,  9.83s/it]
     70%|███████████████████████████████████████████████████████▋                       | 889/1261 [59:23<43:10,  6.97s/it]
     71%|███████████████████████████████████████████████████████▊                       | 890/1261 [59:23<30:30,  4.93s/it]
     71%|███████████████████████████████████████████████████████▊                       | 891/1261 [59:24<22:55,  3.72s/it]
     71%|███████████████████████████████████████████████████████▉                       | 892/1261 [59:24<16:14,  2.64s/it]
     71%|███████████████████████████████████████████████████████▉                       | 893/1261 [59:25<12:14,  2.00s/it]
     71%|████████████████████████████████████████████████████████                       | 894/1261 [59:26<10:01,  1.64s/it]
     71%|████████████████████████████████████████████████████████                       | 895/1261 [59:26<07:34,  1.24s/it]
     71%|████████████████████████████████████████████████████████▏                      | 896/1261 [59:53<55:01,  9.05s/it]
     71%|████████████████████████████████████████████████████████▏                      | 897/1261 [59:53<38:39,  6.37s/it]
     71%|████████████████████████████████████████████████████████▎                      | 898/1261 [59:54<27:21,  4.52s/it]
     71%|████████████████████████████████████████████████████████▎                      | 899/1261 [59:55<21:21,  3.54s/it]
     71%|████████████████████████████████████████████████████████▍                      | 900/1261 [59:55<15:25,  2.56s/it]
     71%|████████████████████████████████████████████████████████▍                      | 901/1261 [59:55<11:05,  1.85s/it]
     72%|████████████████████████████████████████████████████████▌                      | 902/1261 [59:56<09:30,  1.59s/it]
     72%|████████████████████████████████████████████████████████▌                      | 903/1261 [59:57<07:05,  1.19s/it]
     72%|███████████████████████████████████████████████████████▏                     | 904/1261 [1:00:26<58:20,  9.81s/it]
     72%|███████████████████████████████████████████████████████▎                     | 905/1261 [1:00:27<41:09,  6.94s/it]
     72%|███████████████████████████████████████████████████████▎                     | 906/1261 [1:00:27<29:03,  4.91s/it]
     72%|███████████████████████████████████████████████████████▍                     | 907/1261 [1:00:28<21:47,  3.69s/it]
     72%|███████████████████████████████████████████████████████▍                     | 908/1261 [1:00:29<16:46,  2.85s/it]
     72%|███████████████████████████████████████████████████████▌                     | 909/1261 [1:00:29<12:10,  2.08s/it]
     72%|███████████████████████████████████████████████████████▌                     | 910/1261 [1:00:30<09:50,  1.68s/it]
     72%|███████████████████████████████████████████████████████▋                     | 911/1261 [1:00:30<08:00,  1.37s/it]
     72%|██████████████████████████████████████████████████████▏                    | 912/1261 [1:01:02<1:00:08, 10.34s/it]
     72%|███████████████████████████████████████████████████████▊                     | 913/1261 [1:01:02<42:32,  7.34s/it]
     72%|███████████████████████████████████████████████████████▊                     | 914/1261 [1:01:02<30:01,  5.19s/it]
     73%|███████████████████████████████████████████████████████▊                     | 915/1261 [1:01:03<22:17,  3.87s/it]
     73%|███████████████████████████████████████████████████████▉                     | 916/1261 [1:01:03<16:08,  2.81s/it]
     73%|███████████████████████████████████████████████████████▉                     | 917/1261 [1:01:04<12:25,  2.17s/it]
     73%|████████████████████████████████████████████████████████                     | 918/1261 [1:01:04<09:26,  1.65s/it]
     73%|████████████████████████████████████████████████████████                     | 919/1261 [1:01:05<07:19,  1.29s/it]
     73%|████████████████████████████████████████████████████████▏                    | 920/1261 [1:01:32<50:47,  8.94s/it]
     73%|████████████████████████████████████████████████████████▏                    | 921/1261 [1:01:32<36:10,  6.38s/it]
     73%|████████████████████████████████████████████████████████▎                    | 922/1261 [1:01:32<25:30,  4.51s/it]
     73%|████████████████████████████████████████████████████████▎                    | 923/1261 [1:01:33<19:13,  3.41s/it]
     73%|████████████████████████████████████████████████████████▍                    | 924/1261 [1:01:34<14:52,  2.65s/it]
     73%|████████████████████████████████████████████████████████▍                    | 925/1261 [1:01:34<10:50,  1.94s/it]
     73%|████████████████████████████████████████████████████████▌                    | 926/1261 [1:01:35<08:32,  1.53s/it]
     74%|████████████████████████████████████████████████████████▌                    | 927/1261 [1:01:35<06:56,  1.25s/it]
     74%|████████████████████████████████████████████████████████▋                    | 928/1261 [1:02:06<55:50, 10.06s/it]
     74%|████████████████████████████████████████████████████████▋                    | 929/1261 [1:02:06<39:21,  7.11s/it]
     74%|████████████████████████████████████████████████████████▊                    | 931/1261 [1:02:06<27:33,  5.01s/it]
     74%|████████████████████████████████████████████████████████▉                    | 932/1261 [1:02:07<20:23,  3.72s/it]
     74%|████████████████████████████████████████████████████████▉                    | 933/1261 [1:02:07<14:26,  2.64s/it]
     74%|█████████████████████████████████████████████████████████                    | 934/1261 [1:02:08<11:04,  2.03s/it]
     74%|█████████████████████████████████████████████████████████                    | 935/1261 [1:02:08<08:20,  1.53s/it]
     74%|█████████████████████████████████████████████████████████▏                   | 936/1261 [1:02:38<54:53, 10.13s/it]
     74%|█████████████████████████████████████████████████████████▏                   | 937/1261 [1:02:39<38:35,  7.15s/it]
     74%|█████████████████████████████████████████████████████████▎                   | 938/1261 [1:02:39<27:16,  5.07s/it]
     74%|█████████████████████████████████████████████████████████▎                   | 939/1261 [1:02:40<20:43,  3.86s/it]
     75%|█████████████████████████████████████████████████████████▍                   | 940/1261 [1:02:41<15:46,  2.95s/it]
     75%|█████████████████████████████████████████████████████████▍                   | 941/1261 [1:02:41<11:19,  2.12s/it]
     75%|█████████████████████████████████████████████████████████▌                   | 942/1261 [1:02:42<10:11,  1.92s/it]
     75%|█████████████████████████████████████████████████████████▌                   | 943/1261 [1:02:43<07:31,  1.42s/it]
     75%|█████████████████████████████████████████████████████████▋                   | 944/1261 [1:03:14<55:21, 10.48s/it]
     75%|█████████████████████████████████████████████████████████▋                   | 945/1261 [1:03:14<39:04,  7.42s/it]
     75%|█████████████████████████████████████████████████████████▊                   | 946/1261 [1:03:15<27:48,  5.30s/it]
     75%|█████████████████████████████████████████████████████████▊                   | 947/1261 [1:03:16<20:44,  3.96s/it]
     75%|█████████████████████████████████████████████████████████▉                   | 948/1261 [1:03:16<14:56,  2.86s/it]
     75%|█████████████████████████████████████████████████████████▉                   | 949/1261 [1:03:17<11:24,  2.19s/it]
     75%|██████████████████████████████████████████████████████████                   | 950/1261 [1:03:17<08:14,  1.59s/it]
     75%|██████████████████████████████████████████████████████████                   | 951/1261 [1:03:17<06:34,  1.27s/it]
     75%|██████████████████████████████████████████████████████████▏                  | 952/1261 [1:03:46<49:41,  9.65s/it]
     76%|██████████████████████████████████████████████████████████▏                  | 953/1261 [1:03:47<35:15,  6.87s/it]
     76%|██████████████████████████████████████████████████████████▎                  | 954/1261 [1:03:47<24:59,  4.88s/it]
     76%|██████████████████████████████████████████████████████████▎                  | 955/1261 [1:03:48<18:24,  3.61s/it]
     76%|██████████████████████████████████████████████████████████▍                  | 956/1261 [1:03:48<13:12,  2.60s/it]
     76%|██████████████████████████████████████████████████████████▍                  | 957/1261 [1:03:49<11:01,  2.18s/it]
     76%|██████████████████████████████████████████████████████████▍                  | 958/1261 [1:03:50<09:10,  1.82s/it]
     76%|██████████████████████████████████████████████████████████▌                  | 959/1261 [1:03:50<06:46,  1.35s/it]
     76%|██████████████████████████████████████████████████████████▌                  | 960/1261 [1:04:23<53:19, 10.63s/it]
     76%|██████████████████████████████████████████████████████████▋                  | 961/1261 [1:04:23<37:44,  7.55s/it]
     76%|██████████████████████████████████████████████████████████▋                  | 962/1261 [1:04:23<26:56,  5.40s/it]
     76%|██████████████████████████████████████████████████████████▊                  | 963/1261 [1:04:25<20:28,  4.12s/it]
     76%|██████████████████████████████████████████████████████████▊                  | 964/1261 [1:04:25<14:27,  2.92s/it]
     77%|██████████████████████████████████████████████████████████▉                  | 965/1261 [1:04:25<10:50,  2.20s/it]
     77%|██████████████████████████████████████████████████████████▉                  | 966/1261 [1:04:26<08:41,  1.77s/it]
     77%|███████████████████████████████████████████████████████████                  | 967/1261 [1:04:26<06:14,  1.27s/it]
     77%|███████████████████████████████████████████████████████████                  | 968/1261 [1:04:59<52:15, 10.70s/it]
     77%|███████████████████████████████████████████████████████████▏                 | 969/1261 [1:04:59<36:58,  7.60s/it]
     77%|███████████████████████████████████████████████████████████▏                 | 970/1261 [1:04:59<26:14,  5.41s/it]
     77%|███████████████████████████████████████████████████████████▎                 | 971/1261 [1:05:00<19:17,  3.99s/it]
     77%|███████████████████████████████████████████████████████████▎                 | 972/1261 [1:05:01<15:04,  3.13s/it]
     77%|███████████████████████████████████████████████████████████▍                 | 973/1261 [1:05:01<10:52,  2.27s/it]
     77%|███████████████████████████████████████████████████████████▍                 | 974/1261 [1:05:03<09:12,  1.92s/it]
     77%|███████████████████████████████████████████████████████████▌                 | 975/1261 [1:05:03<06:50,  1.44s/it]
     77%|███████████████████████████████████████████████████████████▌                 | 976/1261 [1:05:35<49:57, 10.52s/it]
     77%|███████████████████████████████████████████████████████████▋                 | 977/1261 [1:05:35<35:20,  7.47s/it]
     78%|███████████████████████████████████████████████████████████▋                 | 978/1261 [1:05:35<24:58,  5.29s/it]
     78%|███████████████████████████████████████████████████████████▊                 | 979/1261 [1:05:37<20:17,  4.32s/it]
     78%|███████████████████████████████████████████████████████████▊                 | 980/1261 [1:05:37<14:18,  3.06s/it]
     78%|███████████████████████████████████████████████████████████▉                 | 981/1261 [1:05:38<10:19,  2.21s/it]
     78%|███████████████████████████████████████████████████████████▉                 | 982/1261 [1:05:38<07:55,  1.70s/it]
     78%|████████████████████████████████████████████████████████████                 | 983/1261 [1:05:39<07:01,  1.52s/it]
     78%|████████████████████████████████████████████████████████████                 | 984/1261 [1:06:09<46:07,  9.99s/it]
     78%|████████████████████████████████████████████████████████████▏                | 985/1261 [1:06:09<32:36,  7.09s/it]
     78%|████████████████████████████████████████████████████████████▏                | 986/1261 [1:06:09<23:02,  5.03s/it]
     78%|████████████████████████████████████████████████████████████▎                | 987/1261 [1:06:10<16:58,  3.72s/it]
     78%|████████████████████████████████████████████████████████████▎                | 988/1261 [1:06:11<12:31,  2.75s/it]
     78%|████████████████████████████████████████████████████████████▍                | 989/1261 [1:06:11<09:24,  2.07s/it]
     79%|████████████████████████████████████████████████████████████▍                | 990/1261 [1:06:11<06:45,  1.50s/it]
     79%|████████████████████████████████████████████████████████████▌                | 991/1261 [1:06:12<05:34,  1.24s/it]
     79%|████████████████████████████████████████████████████████████▌                | 992/1261 [1:06:44<47:25, 10.58s/it]
     79%|████████████████████████████████████████████████████████████▋                | 993/1261 [1:06:45<33:32,  7.51s/it]
     79%|████████████████████████████████████████████████████████████▋                | 994/1261 [1:06:45<23:55,  5.37s/it]
     79%|████████████████████████████████████████████████████████████▊                | 995/1261 [1:06:46<17:43,  4.00s/it]
     79%|████████████████████████████████████████████████████████████▊                | 996/1261 [1:06:46<12:57,  2.94s/it]
     79%|████████████████████████████████████████████████████████████▉                | 997/1261 [1:06:47<09:57,  2.26s/it]
     79%|████████████████████████████████████████████████████████████▉                | 998/1261 [1:06:48<07:45,  1.77s/it]
     79%|█████████████████████████████████████████████████████████████                | 999/1261 [1:06:48<06:11,  1.42s/it]
     79%|████████████████████████████████████████████████████████████▎               | 1000/1261 [1:07:19<43:59, 10.11s/it]
     79%|████████████████████████████████████████████████████████████▎               | 1001/1261 [1:07:19<30:57,  7.14s/it]
     79%|████████████████████████████████████████████████████████████▍               | 1002/1261 [1:07:19<21:48,  5.05s/it]
     80%|████████████████████████████████████████████████████████████▍               | 1003/1261 [1:07:20<15:59,  3.72s/it]
     80%|████████████████████████████████████████████████████████████▌               | 1004/1261 [1:07:20<11:43,  2.74s/it]
     80%|████████████████████████████████████████████████████████████▌               | 1005/1261 [1:07:21<09:09,  2.15s/it]
     80%|████████████████████████████████████████████████████████████▋               | 1006/1261 [1:07:21<07:10,  1.69s/it]
     80%|████████████████████████████████████████████████████████████▋               | 1007/1261 [1:07:22<05:32,  1.31s/it]
     80%|████████████████████████████████████████████████████████████▊               | 1008/1261 [1:07:52<41:51,  9.93s/it]
     80%|████████████████████████████████████████████████████████████▊               | 1009/1261 [1:07:52<29:24,  7.00s/it]
     80%|████████████████████████████████████████████████████████████▊               | 1010/1261 [1:07:52<20:50,  4.98s/it]
     80%|████████████████████████████████████████████████████████████▉               | 1011/1261 [1:07:54<16:09,  3.88s/it]
     80%|████████████████████████████████████████████████████████████▉               | 1012/1261 [1:07:54<11:48,  2.84s/it]
     80%|█████████████████████████████████████████████████████████████               | 1013/1261 [1:07:54<08:39,  2.10s/it]
     80%|█████████████████████████████████████████████████████████████               | 1014/1261 [1:07:56<08:06,  1.97s/it]
     80%|█████████████████████████████████████████████████████████████▏              | 1015/1261 [1:07:56<05:51,  1.43s/it]
     81%|█████████████████████████████████████████████████████████████▏              | 1016/1261 [1:08:27<41:37, 10.19s/it]
     81%|█████████████████████████████████████████████████████████████▎              | 1017/1261 [1:08:27<29:23,  7.23s/it]
     81%|█████████████████████████████████████████████████████████████▎              | 1018/1261 [1:08:27<20:43,  5.12s/it]
     81%|█████████████████████████████████████████████████████████████▍              | 1019/1261 [1:08:28<15:17,  3.79s/it]
     81%|█████████████████████████████████████████████████████████████▍              | 1020/1261 [1:08:29<11:49,  2.95s/it]
     81%|█████████████████████████████████████████████████████████████▌              | 1021/1261 [1:08:29<08:26,  2.11s/it]
     81%|█████████████████████████████████████████████████████████████▌              | 1022/1261 [1:08:30<07:02,  1.77s/it]
     81%|█████████████████████████████████████████████████████████████▋              | 1023/1261 [1:08:31<05:37,  1.42s/it]
     81%|█████████████████████████████████████████████████████████████▋              | 1024/1261 [1:09:00<38:03,  9.63s/it]
     81%|█████████████████████████████████████████████████████████████▊              | 1025/1261 [1:09:00<26:59,  6.86s/it]
     81%|█████████████████████████████████████████████████████████████▊              | 1026/1261 [1:09:00<19:06,  4.88s/it]
     81%|█████████████████████████████████████████████████████████████▉              | 1027/1261 [1:09:01<14:11,  3.64s/it]
     82%|█████████████████████████████████████████████████████████████▉              | 1028/1261 [1:09:02<11:18,  2.91s/it]
     82%|██████████████████████████████████████████████████████████████              | 1029/1261 [1:09:02<08:07,  2.10s/it]
     82%|██████████████████████████████████████████████████████████████              | 1030/1261 [1:09:03<05:49,  1.51s/it]
     82%|██████████████████████████████████████████████████████████████▏             | 1031/1261 [1:09:03<05:07,  1.34s/it]
     82%|██████████████████████████████████████████████████████████████▏             | 1032/1261 [1:09:35<39:25, 10.33s/it]
     82%|██████████████████████████████████████████████████████████████▎             | 1033/1261 [1:09:35<27:49,  7.32s/it]
     82%|██████████████████████████████████████████████████████████████▎             | 1034/1261 [1:09:35<19:45,  5.22s/it]
     82%|██████████████████████████████████████████████████████████████▍             | 1035/1261 [1:09:36<14:40,  3.90s/it]
     82%|██████████████████████████████████████████████████████████████▍             | 1036/1261 [1:09:37<10:44,  2.86s/it]
     82%|██████████████████████████████████████████████████████████████▍             | 1037/1261 [1:09:37<07:49,  2.10s/it]
     82%|██████████████████████████████████████████████████████████████▌             | 1038/1261 [1:09:38<06:27,  1.74s/it]
     82%|██████████████████████████████████████████████████████████████▌             | 1039/1261 [1:09:38<04:49,  1.30s/it]
     82%|██████████████████████████████████████████████████████████████▋             | 1040/1261 [1:10:09<37:24, 10.16s/it]
     83%|██████████████████████████████████████████████████████████████▋             | 1041/1261 [1:10:09<26:14,  7.16s/it]
     83%|██████████████████████████████████████████████████████████████▊             | 1042/1261 [1:10:09<18:30,  5.07s/it]
     83%|██████████████████████████████████████████████████████████████▊             | 1043/1261 [1:10:10<13:57,  3.84s/it]
     83%|██████████████████████████████████████████████████████████████▉             | 1044/1261 [1:10:11<10:13,  2.83s/it]
     83%|██████████████████████████████████████████████████████████████▉             | 1045/1261 [1:10:11<07:46,  2.16s/it]
     83%|███████████████████████████████████████████████████████████████             | 1046/1261 [1:10:12<05:50,  1.63s/it]
     83%|███████████████████████████████████████████████████████████████             | 1047/1261 [1:10:13<05:07,  1.44s/it]
     83%|███████████████████████████████████████████████████████████████▏            | 1048/1261 [1:10:44<36:50, 10.38s/it]
     83%|███████████████████████████████████████████████████████████████▏            | 1049/1261 [1:10:44<25:51,  7.32s/it]
     83%|███████████████████████████████████████████████████████████████▎            | 1050/1261 [1:10:45<18:22,  5.22s/it]
     83%|███████████████████████████████████████████████████████████████▎            | 1051/1261 [1:10:45<13:35,  3.88s/it]
     83%|███████████████████████████████████████████████████████████████▍            | 1052/1261 [1:10:46<09:54,  2.85s/it]
     84%|███████████████████████████████████████████████████████████████▍            | 1053/1261 [1:10:46<07:28,  2.16s/it]
     84%|███████████████████████████████████████████████████████████████▌            | 1054/1261 [1:10:47<05:37,  1.63s/it]
     84%|███████████████████████████████████████████████████████████████▌            | 1055/1261 [1:10:47<04:15,  1.24s/it]
     84%|███████████████████████████████████████████████████████████████▋            | 1056/1261 [1:11:17<33:57,  9.94s/it]
     84%|███████████████████████████████████████████████████████████████▋            | 1057/1261 [1:11:18<24:08,  7.10s/it]
     84%|███████████████████████████████████████████████████████████████▊            | 1058/1261 [1:11:18<17:09,  5.07s/it]
     84%|███████████████████████████████████████████████████████████████▊            | 1059/1261 [1:11:19<13:01,  3.87s/it]
     84%|███████████████████████████████████████████████████████████████▉            | 1060/1261 [1:11:20<09:32,  2.85s/it]
     84%|███████████████████████████████████████████████████████████████▉            | 1061/1261 [1:11:20<06:56,  2.08s/it]
     84%|████████████████████████████████████████████████████████████████            | 1062/1261 [1:11:21<05:59,  1.81s/it]
     84%|████████████████████████████████████████████████████████████████            | 1063/1261 [1:11:21<04:18,  1.31s/it]
     84%|████████████████████████████████████████████████████████████████▏           | 1064/1261 [1:11:53<34:21, 10.46s/it]
     84%|████████████████████████████████████████████████████████████████▏           | 1065/1261 [1:11:53<24:06,  7.38s/it]
     85%|████████████████████████████████████████████████████████████████▏           | 1066/1261 [1:11:53<16:56,  5.21s/it]
     85%|████████████████████████████████████████████████████████████████▎           | 1067/1261 [1:11:55<13:23,  4.14s/it]
     85%|████████████████████████████████████████████████████████████████▎           | 1068/1261 [1:11:55<09:35,  2.98s/it]
     85%|████████████████████████████████████████████████████████████████▍           | 1069/1261 [1:11:56<07:26,  2.33s/it]
     85%|████████████████████████████████████████████████████████████████▍           | 1070/1261 [1:11:57<05:57,  1.87s/it]
     85%|████████████████████████████████████████████████████████████████▌           | 1071/1261 [1:11:57<04:35,  1.45s/it]
     85%|████████████████████████████████████████████████████████████████▌           | 1072/1261 [1:12:29<33:26, 10.61s/it]
     85%|████████████████████████████████████████████████████████████████▋           | 1073/1261 [1:12:30<23:30,  7.50s/it]
     85%|████████████████████████████████████████████████████████████████▋           | 1074/1261 [1:12:30<16:39,  5.34s/it]
     85%|████████████████████████████████████████████████████████████████▊           | 1075/1261 [1:12:31<12:23,  4.00s/it]
     85%|████████████████████████████████████████████████████████████████▊           | 1076/1261 [1:12:32<09:25,  3.06s/it]
     85%|████████████████████████████████████████████████████████████████▉           | 1077/1261 [1:12:32<06:50,  2.23s/it]
     85%|████████████████████████████████████████████████████████████████▉           | 1078/1261 [1:12:32<05:08,  1.69s/it]
     86%|█████████████████████████████████████████████████████████████████           | 1079/1261 [1:12:33<04:11,  1.38s/it]
     86%|█████████████████████████████████████████████████████████████████           | 1080/1261 [1:13:03<30:27, 10.09s/it]
     86%|█████████████████████████████████████████████████████████████████▏          | 1081/1261 [1:13:04<21:19,  7.11s/it]
     86%|█████████████████████████████████████████████████████████████████▏          | 1082/1261 [1:13:04<15:07,  5.07s/it]
     86%|█████████████████████████████████████████████████████████████████▎          | 1083/1261 [1:13:05<11:29,  3.88s/it]
     86%|█████████████████████████████████████████████████████████████████▎          | 1084/1261 [1:13:05<08:25,  2.86s/it]
     86%|█████████████████████████████████████████████████████████████████▍          | 1085/1261 [1:13:06<06:03,  2.06s/it]
     86%|█████████████████████████████████████████████████████████████████▍          | 1086/1261 [1:13:07<04:59,  1.71s/it]
     86%|█████████████████████████████████████████████████████████████████▌          | 1087/1261 [1:13:07<03:52,  1.34s/it]
     86%|█████████████████████████████████████████████████████████████████▌          | 1088/1261 [1:13:40<31:08, 10.80s/it]
     86%|█████████████████████████████████████████████████████████████████▋          | 1089/1261 [1:13:40<21:51,  7.62s/it]
     86%|█████████████████████████████████████████████████████████████████▋          | 1090/1261 [1:13:40<15:18,  5.37s/it]
     87%|█████████████████████████████████████████████████████████████████▊          | 1091/1261 [1:13:41<11:03,  3.90s/it]
     87%|█████████████████████████████████████████████████████████████████▊          | 1092/1261 [1:13:41<08:03,  2.86s/it]
     87%|█████████████████████████████████████████████████████████████████▊          | 1093/1261 [1:13:42<06:25,  2.30s/it]
     87%|█████████████████████████████████████████████████████████████████▉          | 1094/1261 [1:13:43<05:03,  1.82s/it]
     87%|█████████████████████████████████████████████████████████████████▉          | 1095/1261 [1:13:43<03:45,  1.36s/it]
     87%|██████████████████████████████████████████████████████████████████          | 1096/1261 [1:14:13<26:56,  9.80s/it]
     87%|██████████████████████████████████████████████████████████████████          | 1097/1261 [1:14:13<18:59,  6.95s/it]
     87%|██████████████████████████████████████████████████████████████████▏         | 1098/1261 [1:14:13<13:24,  4.93s/it]
     87%|██████████████████████████████████████████████████████████████████▏         | 1099/1261 [1:14:14<10:13,  3.79s/it]
     87%|██████████████████████████████████████████████████████████████████▎         | 1100/1261 [1:14:14<07:19,  2.73s/it]
     87%|██████████████████████████████████████████████████████████████████▎         | 1101/1261 [1:14:15<05:36,  2.10s/it]
     87%|██████████████████████████████████████████████████████████████████▍         | 1102/1261 [1:14:16<04:16,  1.61s/it]
     87%|██████████████████████████████████████████████████████████████████▍         | 1103/1261 [1:14:16<03:10,  1.21s/it]
     88%|██████████████████████████████████████████████████████████████████▌         | 1104/1261 [1:14:45<24:50,  9.49s/it]
     88%|██████████████████████████████████████████████████████████████████▌         | 1105/1261 [1:14:45<17:31,  6.74s/it]
     88%|██████████████████████████████████████████████████████████████████▋         | 1106/1261 [1:14:45<12:21,  4.78s/it]
     88%|██████████████████████████████████████████████████████████████████▋         | 1107/1261 [1:14:46<08:57,  3.49s/it]
     88%|██████████████████████████████████████████████████████████████████▊         | 1108/1261 [1:14:46<06:29,  2.54s/it]
     88%|██████████████████████████████████████████████████████████████████▊         | 1109/1261 [1:14:47<05:03,  2.00s/it]
     88%|██████████████████████████████████████████████████████████████████▉         | 1110/1261 [1:14:47<03:44,  1.49s/it]
     88%|██████████████████████████████████████████████████████████████████▉         | 1111/1261 [1:14:47<02:46,  1.11s/it]
     88%|███████████████████████████████████████████████████████████████████         | 1112/1261 [1:15:14<21:47,  8.77s/it]
     88%|███████████████████████████████████████████████████████████████████         | 1113/1261 [1:15:14<15:19,  6.21s/it]
     88%|███████████████████████████████████████████████████████████████████▏        | 1114/1261 [1:15:14<10:47,  4.40s/it]
     88%|███████████████████████████████████████████████████████████████████▏        | 1115/1261 [1:15:15<08:09,  3.35s/it]
     89%|███████████████████████████████████████████████████████████████████▎        | 1116/1261 [1:15:16<05:51,  2.42s/it]
     89%|███████████████████████████████████████████████████████████████████▎        | 1117/1261 [1:15:16<04:17,  1.79s/it]
     89%|███████████████████████████████████████████████████████████████████▍        | 1118/1261 [1:15:17<03:36,  1.51s/it]
     89%|███████████████████████████████████████████████████████████████████▍        | 1119/1261 [1:15:17<02:42,  1.14s/it]
     89%|███████████████████████████████████████████████████████████████████▌        | 1120/1261 [1:15:47<23:01,  9.80s/it]
     89%|███████████████████████████████████████████████████████████████████▌        | 1121/1261 [1:15:47<16:07,  6.91s/it]
     89%|███████████████████████████████████████████████████████████████████▌        | 1122/1261 [1:15:47<11:18,  4.88s/it]
     89%|███████████████████████████████████████████████████████████████████▋        | 1123/1261 [1:15:48<08:09,  3.54s/it]
     89%|███████████████████████████████████████████████████████████████████▋        | 1124/1261 [1:15:48<05:46,  2.53s/it]
     89%|███████████████████████████████████████████████████████████████████▊        | 1125/1261 [1:15:48<04:06,  1.82s/it]
     89%|███████████████████████████████████████████████████████████████████▊        | 1126/1261 [1:15:48<02:58,  1.32s/it]
     89%|███████████████████████████████████████████████████████████████████▉        | 1127/1261 [1:15:48<02:10,  1.03it/s]
     89%|███████████████████████████████████████████████████████████████████▉        | 1128/1261 [1:15:59<08:54,  4.02s/it]
     90%|████████████████████████████████████████████████████████████████████        | 1129/1261 [1:16:00<06:16,  2.85s/it]
     90%|████████████████████████████████████████████████████████████████████        | 1130/1261 [1:16:00<04:25,  2.03s/it]
     90%|████████████████████████████████████████████████████████████████████▏       | 1131/1261 [1:16:01<03:41,  1.71s/it]
     90%|████████████████████████████████████████████████████████████████████▎       | 1133/1261 [1:16:01<02:38,  1.24s/it]
     90%|████████████████████████████████████████████████████████████████████▎       | 1134/1261 [1:16:01<01:57,  1.08it/s]
     90%|████████████████████████████████████████████████████████████████████▍       | 1135/1261 [1:16:01<01:29,  1.40it/s]
     90%|████████████████████████████████████████████████████████████████████▍       | 1136/1261 [1:16:11<06:56,  3.33s/it]
     90%|████████████████████████████████████████████████████████████████████▌       | 1137/1261 [1:16:11<04:53,  2.37s/it]
     90%|████████████████████████████████████████████████████████████████████▌       | 1138/1261 [1:16:11<03:28,  1.69s/it]
     90%|████████████████████████████████████████████████████████████████████▋       | 1139/1261 [1:16:11<02:35,  1.28s/it]
     90%|████████████████████████████████████████████████████████████████████▊       | 1141/1261 [1:16:12<01:51,  1.08it/s]
     91%|████████████████████████████████████████████████████████████████████▊       | 1142/1261 [1:16:12<01:23,  1.42it/s]
     91%|████████████████████████████████████████████████████████████████████▉       | 1143/1261 [1:16:12<01:01,  1.92it/s]
     91%|████████████████████████████████████████████████████████████████████▉       | 1144/1261 [1:16:20<05:30,  2.83s/it]
     91%|█████████████████████████████████████████████████████████████████████       | 1146/1261 [1:16:20<03:50,  2.00s/it]
     91%|█████████████████████████████████████████████████████████████████████▏      | 1147/1261 [1:16:20<02:45,  1.45s/it]
     91%|█████████████████████████████████████████████████████████████████████▏      | 1148/1261 [1:16:20<01:58,  1.05s/it]
     91%|█████████████████████████████████████████████████████████████████████▎      | 1150/1261 [1:16:21<01:24,  1.31it/s]
     91%|█████████████████████████████████████████████████████████████████████▎      | 1151/1261 [1:16:21<01:04,  1.71it/s]
     91%|█████████████████████████████████████████████████████████████████████▍      | 1152/1261 [1:16:29<05:09,  2.84s/it]
     92%|█████████████████████████████████████████████████████████████████████▌      | 1154/1261 [1:16:29<03:35,  2.01s/it]
     92%|█████████████████████████████████████████████████████████████████████▌      | 1155/1261 [1:16:29<02:33,  1.44s/it]
     92%|█████████████████████████████████████████████████████████████████████▋      | 1156/1261 [1:16:29<01:51,  1.06s/it]
     92%|█████████████████████████████████████████████████████████████████████▊      | 1158/1261 [1:16:29<01:18,  1.32it/s]
     92%|█████████████████████████████████████████████████████████████████████▊      | 1159/1261 [1:16:30<01:05,  1.57it/s]
     92%|█████████████████████████████████████████████████████████████████████▉      | 1160/1261 [1:16:38<04:54,  2.91s/it]
     92%|██████████████████████████████████████████████████████████████████████      | 1162/1261 [1:16:38<03:24,  2.06s/it]
     92%|██████████████████████████████████████████████████████████████████████      | 1163/1261 [1:16:38<02:26,  1.50s/it]
     92%|██████████████████████████████████████████████████████████████████████▏     | 1164/1261 [1:16:39<01:45,  1.09s/it]
     92%|██████████████████████████████████████████████████████████████████████▎     | 1166/1261 [1:16:39<01:15,  1.27it/s]
     93%|██████████████████████████████████████████████████████████████████████▎     | 1167/1261 [1:16:39<01:00,  1.57it/s]
     93%|██████████████████████████████████████████████████████████████████████▍     | 1168/1261 [1:16:47<04:33,  2.94s/it]
     93%|██████████████████████████████████████████████████████████████████████▌     | 1170/1261 [1:16:47<03:09,  2.08s/it]
     93%|██████████████████████████████████████████████████████████████████████▌     | 1171/1261 [1:16:48<02:18,  1.53s/it]
     93%|██████████████████████████████████████████████████████████████████████▋     | 1172/1261 [1:16:48<01:38,  1.11s/it]
     93%|██████████████████████████████████████████████████████████████████████▊     | 1174/1261 [1:16:48<01:11,  1.22it/s]
     93%|██████████████████████████████████████████████████████████████████████▊     | 1175/1261 [1:16:48<00:52,  1.64it/s]
     93%|██████████████████████████████████████████████████████████████████████▉     | 1176/1261 [1:16:56<04:04,  2.87s/it]
     93%|██████████████████████████████████████████████████████████████████████▉     | 1178/1261 [1:16:57<02:48,  2.03s/it]
     93%|███████████████████████████████████████████████████████████████████████     | 1179/1261 [1:16:57<02:00,  1.47s/it]
     94%|███████████████████████████████████████████████████████████████████████     | 1180/1261 [1:16:57<01:26,  1.06s/it]
     94%|███████████████████████████████████████████████████████████████████████▏    | 1182/1261 [1:16:57<01:01,  1.29it/s]
     94%|███████████████████████████████████████████████████████████████████████▎    | 1183/1261 [1:16:57<00:47,  1.65it/s]
     94%|███████████████████████████████████████████████████████████████████████▎    | 1184/1261 [1:17:07<04:26,  3.47s/it]
     94%|███████████████████████████████████████████████████████████████████████▍    | 1185/1261 [1:17:07<03:06,  2.46s/it]
     94%|███████████████████████████████████████████████████████████████████████▍    | 1186/1261 [1:17:08<02:11,  1.76s/it]
     94%|███████████████████████████████████████████████████████████████████████▌    | 1187/1261 [1:17:08<01:35,  1.30s/it]
     94%|███████████████████████████████████████████████████████████████████████▌    | 1188/1261 [1:17:08<01:08,  1.06it/s]
     94%|███████████████████████████████████████████████████████████████████████▋    | 1189/1261 [1:17:08<00:54,  1.31it/s]
     94%|███████████████████████████████████████████████████████████████████████▊    | 1191/1261 [1:17:08<00:39,  1.79it/s]
     95%|███████████████████████████████████████████████████████████████████████▊    | 1192/1261 [1:17:17<03:14,  2.81s/it]
     95%|███████████████████████████████████████████████████████████████████████▉    | 1193/1261 [1:17:17<02:16,  2.01s/it]
     95%|███████████████████████████████████████████████████████████████████████▉    | 1194/1261 [1:17:17<01:36,  1.44s/it]
     95%|████████████████████████████████████████████████████████████████████████    | 1195/1261 [1:17:17<01:11,  1.08s/it]
     95%|████████████████████████████████████████████████████████████████████████    | 1196/1261 [1:17:17<00:51,  1.26it/s]
     95%|████████████████████████████████████████████████████████████████████████▏   | 1198/1261 [1:17:17<00:36,  1.70it/s]
     95%|████████████████████████████████████████████████████████████████████████▎   | 1199/1261 [1:17:18<00:28,  2.17it/s]
     95%|████████████████████████████████████████████████████████████████████████▎   | 1200/1261 [1:17:26<02:48,  2.76s/it]
     95%|████████████████████████████████████████████████████████████████████████▍   | 1202/1261 [1:17:26<01:55,  1.96s/it]
     95%|████████████████████████████████████████████████████████████████████████▌   | 1203/1261 [1:17:26<01:23,  1.43s/it]
     95%|████████████████████████████████████████████████████████████████████████▌   | 1204/1261 [1:17:26<00:58,  1.03s/it]
     96%|████████████████████████████████████████████████████████████████████████▌   | 1205/1261 [1:17:26<00:43,  1.27it/s]
     96%|████████████████████████████████████████████████████████████████████████▋   | 1207/1261 [1:17:26<00:30,  1.75it/s]
     96%|████████████████████████████████████████████████████████████████████████▊   | 1208/1261 [1:17:35<02:30,  2.84s/it]
     96%|████████████████████████████████████████████████████████████████████████▊   | 1209/1261 [1:17:35<01:44,  2.02s/it]
     96%|████████████████████████████████████████████████████████████████████████▉   | 1211/1261 [1:17:35<01:12,  1.45s/it]
     96%|█████████████████████████████████████████████████████████████████████████   | 1213/1261 [1:17:35<00:50,  1.04s/it]
     96%|█████████████████████████████████████████████████████████████████████████▏  | 1214/1261 [1:17:35<00:35,  1.31it/s]
     96%|█████████████████████████████████████████████████████████████████████████▏  | 1215/1261 [1:17:35<00:26,  1.74it/s]
     96%|█████████████████████████████████████████████████████████████████████████▎  | 1216/1261 [1:17:44<02:07,  2.84s/it]
     97%|█████████████████████████████████████████████████████████████████████████▍  | 1218/1261 [1:17:44<01:26,  2.02s/it]
     97%|█████████████████████████████████████████████████████████████████████████▍  | 1219/1261 [1:17:44<01:02,  1.50s/it]
     97%|█████████████████████████████████████████████████████████████████████████▌  | 1221/1261 [1:17:44<00:42,  1.07s/it]
     97%|█████████████████████████████████████████████████████████████████████████▋  | 1222/1261 [1:17:44<00:30,  1.27it/s]
     97%|█████████████████████████████████████████████████████████████████████████▋  | 1223/1261 [1:17:44<00:22,  1.67it/s]
     97%|█████████████████████████████████████████████████████████████████████████▊  | 1224/1261 [1:17:52<01:43,  2.80s/it]
     97%|█████████████████████████████████████████████████████████████████████████▉  | 1226/1261 [1:17:53<01:09,  1.98s/it]
     97%|█████████████████████████████████████████████████████████████████████████▉  | 1227/1261 [1:17:53<00:49,  1.46s/it]
     97%|██████████████████████████████████████████████████████████████████████████  | 1228/1261 [1:17:53<00:34,  1.06s/it]
     97%|██████████████████████████████████████████████████████████████████████████  | 1229/1261 [1:17:53<00:24,  1.29it/s]
     98%|██████████████████████████████████████████████████████████████████████████▏ | 1231/1261 [1:17:53<00:17,  1.72it/s]
     98%|██████████████████████████████████████████████████████████████████████████▎ | 1232/1261 [1:18:01<01:23,  2.87s/it]
     98%|██████████████████████████████████████████████████████████████████████████▎ | 1233/1261 [1:18:02<00:57,  2.04s/it]
     98%|██████████████████████████████████████████████████████████████████████████▎ | 1234/1261 [1:18:02<00:39,  1.46s/it]
     98%|██████████████████████████████████████████████████████████████████████████▍ | 1235/1261 [1:18:02<00:28,  1.09s/it]
     98%|██████████████████████████████████████████████████████████████████████████▍ | 1236/1261 [1:18:02<00:20,  1.20it/s]
     98%|██████████████████████████████████████████████████████████████████████████▌ | 1238/1261 [1:18:02<00:14,  1.63it/s]
     98%|██████████████████████████████████████████████████████████████████████████▋ | 1239/1261 [1:18:02<00:10,  2.16it/s]
     98%|██████████████████████████████████████████████████████████████████████████▋ | 1240/1261 [1:18:10<00:56,  2.68s/it]
     98%|██████████████████████████████████████████████████████████████████████████▊ | 1242/1261 [1:18:10<00:36,  1.90s/it]
     99%|██████████████████████████████████████████████████████████████████████████▉ | 1243/1261 [1:18:11<00:24,  1.39s/it]
     99%|██████████████████████████████████████████████████████████████████████████▉ | 1244/1261 [1:18:11<00:17,  1.01s/it]
     99%|███████████████████████████████████████████████████████████████████████████ | 1246/1261 [1:18:11<00:10,  1.37it/s]
     99%|███████████████████████████████████████████████████████████████████████████▏| 1247/1261 [1:18:11<00:07,  1.78it/s]
     99%|███████████████████████████████████████████████████████████████████████████▏| 1248/1261 [1:18:19<00:36,  2.80s/it]
     99%|███████████████████████████████████████████████████████████████████████████▎| 1250/1261 [1:18:19<00:21,  1.99s/it]
     99%|███████████████████████████████████████████████████████████████████████████▍| 1251/1261 [1:18:20<00:14,  1.45s/it]
     99%|███████████████████████████████████████████████████████████████████████████▌| 1253/1261 [1:18:20<00:08,  1.04s/it]
     99%|███████████████████████████████████████████████████████████████████████████▌| 1254/1261 [1:18:20<00:05,  1.29it/s]
    100%|███████████████████████████████████████████████████████████████████████████▋| 1256/1261 [1:18:28<00:08,  1.75s/it]
    100%|███████████████████████████████████████████████████████████████████████████▊| 1257/1261 [1:18:28<00:05,  1.26s/it]
    100%|███████████████████████████████████████████████████████████████████████████▉| 1259/1261 [1:18:28<00:01,  1.09it/s]
    100%|███████████████████████████████████████████████████████████████████████████▉| 1260/1261 [1:18:28<00:00,  1.47it/s]
    

    [MoviePy] Done.
    [MoviePy] >>>> Video ready: project_video_processed.mp4 
    
    Wall time: 1h 18min 31s
    
